// Public Apify Store observations from 2026-09-30. Users are NOT paying-customer counts.
const sources = [
 ['google-maps','Локальные компании и контакты','Лидогенерация','compass/crawler-google-places',627000,4.7,1816,'База компаний по нише и городу: сайт, телефон, адрес и рейтинг.','Рестораны в Люксембурге','business'],
 ['instagram','Публикации Instagram','Соцсети','apify/instagram-scraper',412000,4.7,601,'Публикации публичных аккаунтов для анализа контента и конкурентов.','https://www.instagram.com/example/','social'],
 ['instagram-profiles','Профили Instagram','Лидогенерация','apify/instagram-profile-scraper',232000,4.6,175,'Публичные метрики и описание аккаунтов для подбора партнёров.','example','social'],
 ['tiktok','Контент и тренды TikTok','Соцсети','clockworks/tiktok-scraper',297000,4.8,370,'Видео и показатели вовлечения по выбранной теме.','travel','social'],
 ['google-search','Поисковая выдача Google','Поиск и SEO','apify/google-search-scraper',194000,4.6,218,'Результаты поиска для мониторинга видимости и конкурентов.','best hotels Luxembourg','search'],
 ['instagram-reels','Мониторинг Instagram Reels','Соцсети','apify/instagram-reel-scraper',154000,4.4,103,'Публичные Reels, подписи и показатели просмотров.','https://www.instagram.com/example/','social'],
 ['linkedin-jobs','Вакансии и сигналы найма','Рынок труда','curious_coder/linkedin-jobs-scraper',161000,4.6,141,'Вакансии по роли и рынку для исследования спроса и компаний.','Data engineer Luxembourg','jobs'],
 ['linkedin-posts','Публикации LinkedIn','Соцсети','harvestapi/linkedin-profile-posts',35000,4.4,55,'Публикации публичных профилей для B2B-исследования.','https://www.linkedin.com/in/example/','social'],
 ['meta-ads','Реклама конкурентов в Meta','Рекламная аналитика','apify/facebook-ads-scraper',40000,4.0,59,'Объявления, тексты и ссылки на креативы выбранных рекламодателей.','https://www.facebook.com/ads/library/?view_all_page_id=123456789','ads'],
 ['reddit','Обсуждения и спрос на Reddit','Исследования','fatihtahta/reddit-scraper-search-fast',32000,4.2,20,'Публичные обсуждения по теме для поиска вопросов и потребностей.','workflow automation','social'],
 ['linkedin-company','Новости компаний LinkedIn','Исследования','harvestapi/linkedin-company-posts',11000,5.0,21,'Публикации компаний для мониторинга рынка и конкурентов.','https://www.linkedin.com/company/example/','social'],
 ['tiktok-search','Поиск видео TikTok','Соцсети','xmolodtsov/tiktok-search-scraper',28000,5.0,1,'Поиск видео по ключевым словам с выгрузкой метрик.','skincare','social']
];
export function seedProducts(){return sources.map(([id,title,category,actor,users,rating,reviews,description,example,kind],i)=>({
 id,title,category,actor,description,example,kind,sourceUrl:`https://apify.com/${actor}`,ownerId:null,version:1,status:i<5||id==='meta-ads'?'published':'candidate',
 evidence:{observedAt:'2026-09-30',users,rating,reviews,paidCustomers:null,source:'Apify Store',trend:null},
 priceCents:1900,priceStatus:'scenario',maxItems:100,delivery:'Таблица + CSV + JSON',
 checks:{rights:false,contract:false,quality:false,cost:false},execution:null,measuredCostEurCents:null,
 createdAt:'2026-09-30T00:00:00.000Z',updatedAt:'2026-09-30T00:00:00.000Z'
}));}
export function readiness(p){const missing=[];
 if(!p.checks?.rights)missing.push('Права на коммерческую выдачу');
 if(!p.checks?.contract)missing.push('Проверенный вход Agent и закреплённая версия');
 if(!p.checks?.quality)missing.push('Контрольный запуск и качество результата');
 if(!p.checks?.cost||!Number.isInteger(p.measuredCostEurCents)||p.measuredCostEurCents<=0)missing.push('Измеренная полная себестоимость');
 if(!p.execution?.build||p.execution.build==='latest')missing.push('Закреплённый build');
 if(p.priceStatus!=='approved')missing.push('Утверждённая цена');
 return {ready:!missing.length,missing};
}
export function cleanInput(input={},product){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Некорректное задание.');
 const query=String(input.query||'').trim();
 if(query.length<2||query.length>2000)throw Error('Опишите задачу: от 2 до 2000 символов.');
 const limit=Number(input.limit??100);
 if(!Number.isInteger(limit)||limit<1||limit>product.maxItems)throw Error(`Лимит: от 1 до ${product.maxItems}.`);
 const country=String(input.country||'Worldwide');if(!/^(Worldwide|[A-Z]{2})$/.test(country))throw Error('Укажите двухбуквенный код страны.');
 return {query,limit,country};
}
export function fixtureRows(order){const p=order.product,n=Math.min(order.input.limit,12);return Array.from({length:n},(_,i)=>{
 const base={id:`demo-${p.id}-${i+1}`,title:`${order.input.query.slice(0,70)} · пример ${i+1}`,url:`https://example.com/result/${i+1}`,synthetic:true};
 if(p.kind==='business')return {...base,company:`Demo company ${i+1}`,city:'Luxembourg',phone:'+000 DEMO',rating:4.5};
 if(p.kind==='jobs')return {...base,company:`Demo employer ${i+1}`,location:'Luxembourg',employment:'Full-time'};
 if(p.kind==='search')return {...base,position:i+1,description:'Демонстрационная строка поисковой выдачи.'};
 if(p.kind==='ads')return {...base,advertiser:`Demo brand ${i%3+1}`,text:'Демонстрационный рекламный текст.',format:i%2?'video':'image',status:'active'};
 return {...base,text:'Демонстрационная публикация. Реальные данные появятся после подключения исполнителя.',views:1200+i*113,likes:44+i*7};
 });}
export function normalizeRows(rows,order){
 if(!Array.isArray(rows)||rows.length>order.input.limit)throw Error('Выдача превышает согласованный лимит.');
 const result=rows.filter(r=>r&&typeof r==='object'&&!Array.isArray(r)).map(r=>Object.fromEntries(Object.entries(r).filter(([k])=>!['__proto__','constructor','prototype'].includes(k)).slice(0,60).map(([k,v])=>[k.slice(0,100),typeof v==='object'?JSON.stringify(v).slice(0,10000):String(v??'').slice(0,10000)])));
 const expected=order.product.execution?.requiredOutputFields||['id','title'];
 const valid=result.filter(r=>expected.every(k=>r[k]));
 return {ads:valid,quality:{complete:valid.length>0&&valid.length===rows.length,rows:valid.length,requested:order.input.limit,synthetic:order.providerMode==='fixture'}};
}
export function csv(rows){if(!rows.length)return '';const keys=[...new Set(rows.flatMap(Object.keys))];const cell=v=>{let s=String(v??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};return '\uFEFF'+[keys,...rows.map(r=>keys.map(k=>r[k]))].map(row=>row.map(cell).join(',')).join('\r\n');}
