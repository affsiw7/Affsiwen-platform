import {customerProduct} from './product-content.mjs';
import {randomUUID,createHash} from 'node:crypto';
import {Store,HttpError} from './store.mjs';
import {seedProducts,cleanInput,readiness} from './catalog.mjs';
const check=(x,status,msg)=>{if(!x)throw new HttpError(status,msg);};
const stamp=()=>new Date().toISOString();
export class MarketStore extends Store {
 constructor(path){super(path);this.db.exec(`
 CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,body TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,order_id TEXT NOT NULL REFERENCES orders(id),author_id TEXT NOT NULL REFERENCES users(id),body TEXT NOT NULL,created TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS favorites(user_id TEXT NOT NULL REFERENCES users(id),product_id TEXT NOT NULL REFERENCES products(id),PRIMARY KEY(user_id,product_id));
 CREATE TABLE IF NOT EXISTS catalog_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id TEXT NOT NULL,user_id TEXT,event TEXT NOT NULL,created TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS execution_budget(order_id TEXT PRIMARY KEY REFERENCES orders(id),day TEXT NOT NULL,reserved_usd_cents INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS ledger(id TEXT PRIMARY KEY,order_id TEXT NOT NULL REFERENCES orders(id),kind TEXT NOT NULL,cents INTEGER NOT NULL,currency TEXT NOT NULL,created TEXT NOT NULL,UNIQUE(order_id,kind));
 `);const insert=this.db.prepare('INSERT OR IGNORE INTO products VALUES(?,?)');for(const p of seedProducts())insert.run(p.id,JSON.stringify(p));}
 product(id){const r=this.db.prepare('SELECT body FROM products WHERE id=?').get(id);return r?JSON.parse(r.body):null;}
 catalog(user){return this.db.prepare('SELECT body FROM products').all().map(r=>JSON.parse(r.body)).filter(p=>user?.role==='operator'||p.status==='published'||p.ownerId===user?.id).map(p=>this.publicProduct(p,user));}
 publicProduct(p,user){const c=customerProduct(p);if(user?.role==='operator'||(user&&p.ownerId===user.id)){c.readiness=readiness(p);c.ownerId=p.ownerId;c.submission=p.submission||null;c.reviewNote=p.reviewNote||'';}return c;}
 putProduct(p,user,event){p.updatedAt=stamp();this.db.prepare('INSERT INTO products VALUES(?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body').run(p.id,JSON.stringify(p));this.db.prepare('INSERT INTO catalog_audit(product_id,user_id,event,created) VALUES(?,?,?,?)').run(p.id,user.id,event,stamp());return this.publicProduct(p,user);}
 propose(user,data){check(['supplier','operator'].includes(user.role),403,'Нужен поставщик или оператор.');
  check(/^[a-zA-Z0-9_-]{1,100}\/[a-zA-Z0-9_-]{1,100}$/.test(data.actor||''),400,'Agent: автор/название.');
  const text=(v,n)=>String(v||'').trim().slice(0,n);check(text(data.title,120).length>=3,400,'Название от 3 символов.');
  check(!this.db.prepare('SELECT body FROM products').all().some(r=>JSON.parse(r.body).actor===data.actor),409,'Этот Agent уже есть в отборе.');
  const p={id:randomUUID(),title:text(data.title,120),description:text(data.description,1000),category:text(data.category,60)||'Исследования',actor:data.actor,sourceUrl:`https://apify.com/${data.actor}`,ownerId:user.id,status:'candidate',version:1,kind:'social',example:'Тема исследования',priceCents:1900,priceStatus:'scenario',maxItems:100,delivery:'Таблица + CSV + JSON',evidence:{users:null,rating:null,reviews:null,paidCustomers:null,observedAt:null},checks:{rights:false,contract:false,quality:false,cost:false},execution:null,measuredCostEurCents:null,createdAt:stamp()};if(data.submission!==undefined){const b=data.submission;check(b&&typeof b==='object'&&!Array.isArray(b),400,'Некорректная заявка.');const fields=['audience','inputExample','outputFields','limitations'];check(fields.every(k=>typeof b[k]==='string'&&b[k].trim().length>=3&&b[k].length<=1000),400,'Заполните аудиторию, пример задания, поля результата и ограничения.');p.submission=Object.fromEntries(fields.map(k=>[k,b[k].trim()]));}return this.transaction(()=>this.putProduct(p,user,'candidate.submitted'));
 }
 revise(user,id,data){check(user.role==='operator',403,'Публикует только оператор.');return this.transaction(()=>{const p=this.product(id);check(p,404,'Продукт не найден.');check(data.version===p.version,409,'Продукт уже изменён. Обновите страницу.');
  if(data.title!==undefined){check(typeof data.title==='string'&&data.title.trim().length>=3&&data.title.length<=120,400,'Некорректное название.');p.title=data.title.trim();}
  if(data.priceCents!==undefined){check(Number.isInteger(data.priceCents)&&data.priceCents>=100&&data.priceCents<=100000,400,'Цена: €1–1000.');if(p.priceCents!==data.priceCents){p.priceStatus='scenario';p.checks.cost=false;}p.priceCents=data.priceCents;}
  if(data.reviewNote!==undefined){check(typeof data.reviewNote==='string'&&data.reviewNote.length<=2000,400,'Комментарий: до 2000 символов.');p.reviewNote=data.reviewNote.trim();}
  if(data.status!==undefined){check(['candidate','published','paused','rejected'].includes(data.status),400,'Неверный статус.');p.status=data.status;}
  // Publishing a demonstration does not assert commercial rights or verified economics.
  p.version++;return this.putProduct(p,user,'product.'+p.status);
 });}
 create(user,data,paymentMode='fixture'){
  if(!data.productId)return super.create(user,data,paymentMode);
  check(user.role==='buyer',403,'Заказы оформляет покупатель.');check(/^[\w-]{8,100}$/.test(data.key||''),400,'Нужен ключ повторной отправки.');
  const p=this.product(data.productId);check(p?.status==='published',409,'Продукт недоступен для заказа.');let input;try{input=cleanInput(data.input,p);}catch(e){throw new HttpError(400,e.message);}
  const fingerprint=createHash('sha256').update(JSON.stringify({productId:p.id,input})).digest('hex');
  return this.transaction(()=>{const old=this.db.prepare('SELECT body,fingerprint FROM orders WHERE buyer_id=? AND key=?').get(user.id,data.key);if(old){check(old.fingerprint===fingerprint,409,'Ключ уже использован для другого заказа.');return JSON.parse(old.body);}
   const o={id:randomUUID(),buyerId:user.id,input,product:structuredClone(p),productId:p.id,amountCents:p.priceCents,priceStatus:p.priceStatus,currency:'eur',status:'awaiting_payment',paymentMode,providerMode:null,created:stamp(),runId:null,costUsd:null,result:null,error:null};
   this.db.prepare('INSERT INTO orders VALUES(?,?,?,?,?)').run(o.id,user.id,data.key,fingerprint,JSON.stringify(o));this.audit(o.id,'order.created');return o;
  });
 }
 qualify(user,id,data){check(user.role==='operator',403,'Нужен оператор.');return this.transaction(()=>{const p=this.product(id);check(p,404,'Продукт не найден.');check(p.version===data.version,409,'Версия продукта изменилась.');
  for(const key of ['rightsReference','testRunReference','costReference'])check(typeof data[key]==='string'&&data[key].length>=10&&data[key].length<=1000,400,'Нужны ссылки или номера документов: права, контрольный запуск, сверка стоимости.');
  const e=data.execution;check(e&&typeof e==='object'&&/^[a-zA-Z0-9_.-]{1,80}$/.test(e.build||'')&&e.build!=='latest',400,'Укажите закреплённый build Agent.');
  check(e.mapping&&typeof e.mapping==='object'&&!Array.isArray(e.mapping)&&Object.keys(e.mapping).length<=20,400,'Нужно проверенное соответствие полей.');
  check(Object.entries(e.mapping).every(([k,v])=>/^[a-zA-Z][a-zA-Z0-9_]{0,80}$/.test(k)&&!['constructor','prototype','__proto__'].includes(k)&&['query','limit','country'].includes(v)),400,'Неверное соответствие полей.');
  check(e.template&&typeof e.template==='object'&&!Array.isArray(e.template)&&JSON.stringify(e.template).length<10000,400,'Нужен шаблон входа Agent.');
  check(Array.isArray(e.requiredOutputFields)&&e.requiredOutputFields.length>0&&e.requiredOutputFields.length<=20&&e.requiredOutputFields.every(k=>typeof k==='string'&&/^[a-zA-Z][a-zA-Z0-9_]{0,80}$/.test(k)),400,'Укажите обязательные поля выдачи.');
  check(Number.isInteger(data.measuredCostEurCents)&&data.measuredCostEurCents>0&&data.measuredCostEurCents<p.priceCents,400,'Полная себестоимость должна быть измерена и быть ниже цены.');
  p.execution=e;p.measuredCostEurCents=data.measuredCostEurCents;p.qualification={rightsReference:data.rightsReference,testRunReference:data.testRunReference,costReference:data.costReference,reviewedBy:user.id,reviewedAt:stamp(),method:'operator-attestation'};p.checks={rights:true,contract:true,quality:true,cost:true};p.priceStatus='approved';p.version++;return this.putProduct(p,user,'qualification.attested');
 });}
 claim(mode){if(mode!=='apify')return super.claim(mode);return this.transaction(()=>{const o=this.all().find(o=>o.status==='queued');if(!o)return null;
  if(!o.product||!readiness(o.product).ready||o.paymentMode!=='stripe_test'){o.status='review';o.error='Реальное исполнение заблокировано: нужен утверждённый продукт и Stripe sandbox.';this.save(o,'launch.blocked');return null;}
  const day=stamp().slice(0,10),reserved=Math.ceil(Number(process.env.APIFY_MAX_RUN_USD||2)*100),cap=Math.floor(Number(process.env.APIFY_DAILY_CAP_USD||10)*100);
  check(Number.isSafeInteger(reserved)&&reserved>0&&Number.isSafeInteger(cap)&&cap>=reserved,503,'Неверный бюджет исполнения.');
  const used=this.db.prepare('SELECT COALESCE(SUM(reserved_usd_cents),0) n FROM execution_budget WHERE day=?').get(day).n;
  if(used+reserved>cap){o.status='review';o.error='Дневной лимит зарезервированного бюджета исчерпан.';this.save(o,'budget.blocked');return null;}
  this.db.prepare('INSERT INTO execution_budget VALUES(?,?,?)').run(o.id,day,reserved);o.status='starting';o.providerMode=mode;o.started=stamp();return this.save(o,'provider.start_requested');
 });}
 publicOrder(user,o){const c=super.publicOrder(user,o);if(c.product)c.product=this.publicProduct(c.product,user);if(c.providerMode&&c.providerMode!=='fixture')c.providerMode='managed';return c;}
 save(o,event){super.save(o,event);const kinds={'payment.fixture_confirmed':'test_payment','payment.stripe_test_confirmed':'test_payment','refund.fixture_confirmed':'test_refund'};if(kinds[event])this.db.prepare('INSERT OR IGNORE INTO ledger VALUES(?,?,?,?,?,?)').run(randomUUID(),o.id,kinds[event],event.startsWith('refund')?-o.amountCents:o.amountCents,o.currency,stamp());return o;}
 events(user,id){this.read(user,id);return this.db.prepare('SELECT event,created FROM audit WHERE order_id=? ORDER BY id').all(id);}
 messages(user,id){this.read(user,id);return this.db.prepare('SELECT m.id,m.body,m.created,u.role FROM messages m JOIN users u ON u.id=m.author_id WHERE order_id=? ORDER BY m.created').all(id);}
 message(user,id,body){this.read(user,id);check(typeof body==='string'&&body.trim().length>0&&body.length<=4000,400,'Сообщение: 1–4000 символов.');this.db.prepare('INSERT INTO messages VALUES(?,?,?,?,?)').run(randomUUID(),id,user.id,body.trim(),stamp());return this.messages(user,id);}
 favorite(user,id){check(this.product(id)?.status==='published',404,'Продукт не найден.');const found=this.db.prepare('SELECT 1 FROM favorites WHERE user_id=? AND product_id=?').get(user.id,id);if(found)this.db.prepare('DELETE FROM favorites WHERE user_id=? AND product_id=?').run(user.id,id);else this.db.prepare('INSERT INTO favorites VALUES(?,?)').run(user.id,id);return this.favorites(user);}
 favorites(user){return this.db.prepare('SELECT product_id FROM favorites WHERE user_id=?').all(user.id).map(r=>r.product_id);}
 cancel(user,id){return this.transaction(()=>{const o=this.get(id);check(o?.buyerId===user.id,404,'Заказ не найден.');check(o.status==='awaiting_payment'&&o.paymentMode==='fixture',409,'Отмена недоступна: оплату или выполнение нужно сверить.');o.status='cancelled';return this.save(o,'order.cancelled');});}
 dispute(user,id,reason){return this.transaction(()=>{const o=this.get(id);check(o?.buyerId===user.id,404,'Заказ не найден.');check(['delivered','accepted'].includes(o.status),409,'Оспорить можно выданный результат.');check(typeof reason==='string'&&reason.trim().length>=5&&reason.length<=2000,400,'Опишите проблему: 5–2000 символов.');o.status='review';o.error='Покупатель запросил проверку результата.';this.save(o,'buyer.disputed');this.message(user,id,reason);return o;});}
 resume(user,id){return this.transaction(()=>{check(user.role==='operator',403,'Нужен оператор.');const o=this.get(id);check(o?.status==='review'&&o.runId,409,'Нужен существующий запуск на проверке.');o.status='running';o.pollErrors=0;o.error=null;return this.save(o,'operator.reread_existing_run');});}
 reconcileCost(user,id,data){check(user.role==='operator',403,'Нужен оператор.');return this.transaction(()=>{const o=this.get(id);check(o,404,'Заказ не найден.');check(o.providerMode!=='fixture',409,'Нельзя выдать синтетические расходы за реальную себестоимость.');check(Number.isInteger(data.costEurCents)&&data.costEurCents>=0&&data.costEurCents<=100000,400,'Укажите расходы в евроцентах.');check(typeof data.reference==='string'&&data.reference.length>=5&&data.reference.length<300,400,'Нужна ссылка или номер сверки счёта.');o.costEurCents=data.costEurCents;o.costReference=data.reference;return this.save(o,'cost.reconciled');});}
 overview(user){check(user.role==='operator',403,'Нужен оператор.');const orders=this.all(),products=this.catalog(user);return {orders:orders.length,needsReview:orders.filter(o=>['review','reconciliation'].includes(o.status)).length,queued:orders.filter(o=>['queued','starting','running'].includes(o.status)).length,commercialRevenueCents:0,testVolumeCents:Number(this.db.prepare('SELECT COALESCE(SUM(cents),0) AS n FROM ledger').get().n),costUnknown:orders.filter(o=>o.status!=='awaiting_payment'&&o.costEurCents===undefined).length,products:products.map(p=>{const os=orders.filter(o=>o.productId===p.id);return {id:p.id,title:p.title,orders:os.length,delivered:os.filter(o=>['accepted','delivered'].includes(o.status)).length,testPaid:os.filter(o=>!['awaiting_payment','cancelled'].includes(o.status)).length,commercialPaid:0,repeatBuyers:[...new Set(os.map(o=>o.buyerId))].filter(id=>os.filter(o=>o.buyerId===id&&!['awaiting_payment','cancelled','refunded'].includes(o.status)).length>1).length};})};}
}
