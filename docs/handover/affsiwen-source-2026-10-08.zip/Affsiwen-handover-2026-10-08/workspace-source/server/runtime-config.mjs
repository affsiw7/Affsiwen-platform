// Prefer the explicitly configured canonical origin. Render supplies its exact
// assigned HTTPS URL; do not derive a trusted origin from request headers.
export function publicOrigin(env = process.env, port = 4180) {
  const candidate = env.PUBLIC_ORIGIN || env.RENDER_EXTERNAL_URL || `http://127.0.0.1:${port}`;
  const url = new URL(candidate);
  if (url.username || url.password || url.search || url.hash || url.pathname !== '/' || !['http:', 'https:'].includes(url.protocol)) {
    throw Error('PUBLIC_ORIGIN must be an HTTP(S) origin without credentials, path, query or fragment');
  }
  const local = ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname);
  if ((!local || env.NODE_ENV === 'staging') && url.protocol !== 'https:') {
    throw Error('External staging requires an HTTPS origin');
  }
  if (env.NODE_ENV === 'staging' && env.LOCAL_DEMO_ACCESS === 'yes') {
    throw Error('Local demo role access is forbidden on staging');
  }
  return url.origin;
}
