import {DatabaseSync} from 'node:sqlite';
import {randomUUID,createHash,randomBytes,scryptSync,timingSafeEqual} from 'node:crypto';
import {validateAdsInput,normalizeAds} from '../dist/ads.js';
import {normalizeRows} from './catalog.mjs';
import {HttpError} from './errors.mjs';
export {HttpError} from './errors.mjs';
const assert=(ok,status,message)=>{if(!ok)throw new HttpError(status,message);};
const hash=v=>createHash('sha256').update(v).digest('hex');
export class Store{
 constructor(path=':memory:'){
  this.db=new DatabaseSync(path);this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
   CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('buyer','supplier','operator')));
   CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires INTEGER NOT NULL);
   CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,buyer_id TEXT NOT NULL REFERENCES users(id),key TEXT NOT NULL,fingerprint TEXT NOT NULL,body TEXT NOT NULL,UNIQUE(buyer_id,key));
   CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id TEXT NOT NULL,event TEXT NOT NULL,created TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS payment_events(id TEXT PRIMARY KEY,order_id TEXT NOT NULL);
  `);
 }
 close(){this.db.close();}
 transaction(fn){this.db.exec('BEGIN IMMEDIATE');try{const result=fn();this.db.exec('COMMIT');return result;}catch(e){this.db.exec('ROLLBACK');throw e;}}
 register({email,password,role='buyer'},internal=false){
  assert(typeof email==='string'&&email.length<200&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),400,'Укажите email.');
  assert(typeof password==='string'&&password.length>=12&&password.length<=128,400,'Пароль: от 12 до 128 символов.');
  assert(['buyer','supplier'].includes(role)||(internal&&role==='operator'),403,'Эту роль нельзя зарегистрировать.');
  const salt=randomBytes(16).toString('hex'),pw=scryptSync(password,salt,64).toString('hex');
  const user={id:randomUUID(),email:email.trim().toLowerCase(),role};
  try{this.db.prepare('INSERT INTO users VALUES(?,?,?,?)').run(user.id,user.email,`${salt}:${pw}`,role);}catch{throw new HttpError(409,'Аккаунт уже существует.');}return user;
 }
 login({email,password}){
  const user=this.db.prepare('SELECT * FROM users WHERE email=?').get(String(email).trim().toLowerCase());
  const [salt,expected]=(user?.password||`${'0'.repeat(32)}:${'0'.repeat(128)}`).split(':');
  const actual=scryptSync(String(password).slice(0,128),salt,64);
  assert(user&&timingSafeEqual(actual,Buffer.from(expected,'hex')),401,'Неверный email или пароль.');
  const token=randomBytes(32).toString('hex');this.db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
  this.db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(token),user.id,Date.now()+86400000);
  return {token,user:{id:user.id,email:user.email,role:user.role}};
 }
 user(token=''){return this.db.prepare('SELECT u.id,u.email,u.role FROM sessions s JOIN users u ON s.user_id=u.id WHERE token_hash=? AND expires>?').get(hash(token),Date.now());}
 logout(token=''){this.db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hash(token));}
 get(id){const row=this.db.prepare('SELECT body FROM orders WHERE id=?').get(id);return row?JSON.parse(row.body):null;}
 all(){return this.db.prepare('SELECT body FROM orders ORDER BY rowid DESC').all().map(r=>JSON.parse(r.body));}
 visible(user){return this.all().filter(o=>user.role==='operator'||o.buyerId===user.id).map(o=>this.publicOrder(user,o));}
 read(user,id){const o=this.get(id);assert(o&&(user.role==='operator'||o.buyerId===user.id),404,'Заказ не найден.');return this.publicOrder(user,o);}
 publicOrder(user,o){const copy=structuredClone(o);if(user.role!=='operator'){delete copy.costUsd;delete copy.costEurCents;delete copy.costReference;delete copy.runId;delete copy.paymentSessionId;delete copy.providerBilling;}return copy;}
 save(o,event){this.db.prepare('UPDATE orders SET body=? WHERE id=?').run(JSON.stringify(o),o.id);this.audit(o.id,event);return o;}
 audit(id,event){this.db.prepare('INSERT INTO audit(order_id,event,created) VALUES(?,?,?)').run(id,event,new Date().toISOString());}
 create(user,{input,key},paymentMode='fixture'){
  assert(user.role==='buyer',403,'Заказы оформляет покупатель.');
  assert(typeof key==='string'&&/^[\w-]{8,100}$/.test(key),400,'Нужен ключ повторной отправки.');
  let valid;try{valid=validateAdsInput(input);}catch(e){throw new HttpError(400,e.message);}
  const fingerprint=hash(JSON.stringify(valid));
  return this.transaction(()=>{
   const prior=this.db.prepare('SELECT body,fingerprint FROM orders WHERE buyer_id=? AND key=?').get(user.id,key);
   if(prior){assert(prior.fingerprint===fingerprint,409,'Этот ключ уже использован с другими параметрами.');return JSON.parse(prior.body);}
   const o={id:randomUUID(),buyerId:user.id,input:valid,amountCents:1900,priceStatus:'scenario-not-approved',currency:'eur',status:'awaiting_payment',paymentMode,providerMode:null,created:new Date().toISOString(),runId:null,costUsd:null,result:null,error:null};
   this.db.prepare('INSERT INTO orders VALUES(?,?,?,?,?)').run(o.id,user.id,key,fingerprint,JSON.stringify(o));this.audit(o.id,'order.created');return o;
  });
 }
 payFixture(user,id){return this.transaction(()=>{const o=this.get(id);assert(o?.buyerId===user.id,404,'Заказ не найден.');assert(o.paymentMode==='fixture',409,'Для этого заказа нужен Stripe.');if(o.status==='queued')return o;assert(o.status==='awaiting_payment',409,'Оплата больше недоступна.');o.status='queued';return this.save(o,'payment.fixture_confirmed');});}
 recordStripe(event){
  if(!['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type))return;
  return this.transaction(()=>{
   if(this.db.prepare('SELECT id FROM payment_events WHERE id=?').get(event.id))return;
   const s=event.data.object,o=this.get(s.metadata?.order_id);
   assert(o&&o.paymentMode==='stripe_test'&&s.id===o.paymentSessionId&&s.client_reference_id===o.id&&s.amount_total===o.amountCents&&s.currency===o.currency&&event.livemode===false,400,'Stripe payment does not match order');
   if(s.payment_status!=='paid')return;
   assert(o.status==='awaiting_payment'||o.status==='queued'||o.status==='starting'||o.status==='running'||o.status==='delivered'||o.status==='accepted'||o.status==='review',409,'Order cannot accept payment');
   this.db.prepare('INSERT INTO payment_events VALUES(?,?)').run(event.id,o.id);
   if(o.status==='awaiting_payment'){o.status='queued';this.save(o,'payment.stripe_test_confirmed');}
  });
 }
 claim(providerMode){return this.transaction(()=>{const o=this.all().find(o=>o.status==='queued');if(!o)return null;o.status='starting';o.providerMode=providerMode;o.started=new Date().toISOString();return this.save(o,'provider.start_requested');});}
 recover(){for(const o of this.all().filter(o=>o.status==='starting')){o.status='reconciliation';o.error='Сервер перезапустился во время запуска. Нужна проверка исполнителя; автоматического повтора нет.';this.save(o,'provider.start_uncertain');}}
 accept(user,id){return this.transaction(()=>{const o=this.get(id);assert(o?.buyerId===user.id,404,'Заказ не найден.');if(o.status==='accepted')return o;assert(o.status==='delivered',409,'Результат ещё не готов.');o.status='accepted';return this.save(o,'buyer.accepted');});}
 refundFixture(user,id){return this.transaction(()=>{assert(user.role==='operator',403,'Нужен оператор.');const o=this.get(id);assert(o,404,'Заказ не найден.');assert(o.paymentMode==='fixture',409,'Реальный возврат здесь не подключён.');if(o.status==='refunded')return o;assert(['review','delivered','accepted'].includes(o.status),409,'Возврат доступен после завершения исполнения.');o.status='refunded';return this.save(o,'refund.fixture_confirmed');});}
}
export class Worker{
 constructor(store,provider){Object.assign(this,{store,provider});this.busy=false;}
 async tick(){
  if(this.busy)return;this.busy=true;
  try{
   const o=this.store.claim(this.provider.mode);
   if(o){try{const run=await this.provider.start(o);o.runId=run.id;o.status='running';this.store.save(o,'provider.started');}catch{o.status='reconciliation';o.error='Не удалось подтвердить запуск. Проверьте историю исполнителя до повторной отправки.';this.store.save(o,'provider.start_uncertain');}}
   for(const order of this.store.all().filter(o=>o.status==='running')){
    try{const run=await this.provider.poll(order);
     if(['FAILED','TIMED-OUT','ABORTED'].includes(run.status)){order.status='review';order.error='Исполнитель завершился без готового результата.';order.costUsd=null;order.providerBilling={usageTotalUsd:Number.isFinite(run.usageTotalUsd)?run.usageTotalUsd:null,chargedEventCounts:run.chargedEventCounts||null,pricingInfo:run.pricingInfo||null,reconciled:false};this.store.save(order,'provider.failed');continue;}
     if(run.status!=='SUCCEEDED')continue;
     const rows=await this.provider.results(order,run),normalized=order.product?normalizeRows(rows,order):normalizeAds(rows,order.input);
     order.costUsd=null;order.providerBilling={usageTotalUsd:Number.isFinite(run.usageTotalUsd)?run.usageTotalUsd:null,chargedEventCounts:run.chargedEventCounts||null,pricingInfo:run.pricingInfo||null,reconciled:false};order.result=normalized.ads;order.quality=normalized.quality;order.finished=new Date().toISOString();
     order.status=normalized.quality.complete?'delivered':'review';order.error=normalized.quality.complete?null:'Пустой или неполный результат. Требуется проверка; полная выдача не подтверждена.';
     this.store.save(order,order.status==='delivered'?'result.delivered':'result.review');
    }catch{order.pollErrors=(order.pollErrors||0)+1;order.error='Временная ошибка чтения результата.';if(order.pollErrors>=5){order.status='review';order.error='Не удалось прочитать результат. Нужна проверка оператора; новый запуск не создан.';}this.store.save(order,'provider.read_failed');}
   }
  }finally{this.busy=false;}
 }
}
