import {randomBytes,createHash,createPublicKey,verify} from 'node:crypto';
import {HttpError} from './store.mjs';
const hash=x=>createHash('sha256').update(x).digest('hex');
const random=()=>randomBytes(32).toString('hex');
const fail=()=>{throw new HttpError(401,'Не удалось подтвердить вход Google. Начните вход заново.');};
export function verifyIdToken(token,keys,{clientId,nonce,now=Date.now()/1000}){
 try{
  if(typeof token!=='string'||token.length>16000)fail();
  const parts=token.split('.');if(parts.length!==3)fail();
  const header=JSON.parse(Buffer.from(parts[0],'base64url')),p=JSON.parse(Buffer.from(parts[1],'base64url'));
  const key=keys.find(k=>k.kid===header.kid&&k.kty==='RSA'&&(!k.alg||k.alg==='RS256')&&(!k.use||k.use==='sig'));
  if(header.alg!=='RS256'||!key||!verify('RSA-SHA256',Buffer.from(parts.slice(0,2).join('.')),createPublicKey({key,format:'jwk'}),Buffer.from(parts[2],'base64url')))fail();
  if(!['https://accounts.google.com','accounts.google.com'].includes(p.iss)||p.aud!==clientId||(p.azp&&p.azp!==clientId)||p.nonce!==nonce||!Number.isFinite(p.exp)||p.exp<=now||!Number.isFinite(p.iat)||p.iat>now+60||typeof p.sub!=='string'||!p.sub||p.sub.length>255||p.email_verified!==true||typeof p.email!=='string'||!/^\S+@\S+\.\S+$/.test(p.email))fail();
  return {sub:p.sub,email:p.email.toLowerCase()};
 }catch{fail();}
}
export class GoogleAuth{
 constructor(store,{clientId,clientSecret,origin,fetcher=fetch}){
  Object.assign(this,{store,clientId,clientSecret,origin,fetcher});
  this.enabled=!!(clientId&&clientSecret);
  store.db.exec(`CREATE TABLE IF NOT EXISTS google_identities(sub TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id));CREATE TABLE IF NOT EXISTS google_states(state_hash TEXT PRIMARY KEY,binding_hash TEXT NOT NULL,nonce TEXT NOT NULL,verifier TEXT NOT NULL,expires INTEGER NOT NULL);`);
 }
 start(){
  if(!this.enabled)throw new HttpError(503,'Вход Google ещё настраивается.');
  const state=random(),binding=random(),nonce=random(),verifier=random();
  this.store.db.prepare('DELETE FROM google_states WHERE expires<?').run(Date.now());
  this.store.db.prepare('INSERT INTO google_states VALUES(?,?,?,?,?)').run(hash(state),hash(binding),nonce,verifier,Date.now()+600000);
  const url=new URL('https://accounts.google.com/o/oauth2/v2/auth');url.search=new URLSearchParams({client_id:this.clientId,redirect_uri:this.origin+'/api/auth/google/callback',response_type:'code',scope:'openid email',state,nonce,prompt:'select_account',code_challenge:createHash('sha256').update(verifier).digest('base64url'),code_challenge_method:'S256'}).toString();
  return {url:url.href,binding};
 }
 consume(state,binding){
  if(!/^[a-f0-9]{64}$/.test(state||'')||!/^[a-f0-9]{64}$/.test(binding||''))fail();
  return this.store.transaction(()=>{const r=this.store.db.prepare('SELECT * FROM google_states WHERE state_hash=?').get(hash(state));if(!r||r.binding_hash!==hash(binding)||r.expires<Date.now())fail();this.store.db.prepare('DELETE FROM google_states WHERE state_hash=?').run(hash(state));return r;});
 }
 async finish(state,binding,code){
  if(!this.enabled)fail();const r=this.consume(state,binding);if(typeof code!=='string'||code.length>4000||!code)fail();
  const response=await this.fetcher('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code,client_id:this.clientId,client_secret:this.clientSecret,redirect_uri:this.origin+'/api/auth/google/callback',grant_type:'authorization_code',code_verifier:r.verifier}),redirect:'error',signal:AbortSignal.timeout(15000)});if(!response.ok)fail();
  const tokens=await response.json();
  if(!this.keys||this.keysExpire<Date.now()){const jwks=await this.fetcher('https://www.googleapis.com/oauth2/v3/certs',{redirect:'error',signal:AbortSignal.timeout(15000)});if(!jwks.ok)fail();this.keys=(await jwks.json()).keys;this.keysExpire=Date.now()+300000;}
  const identity=verifyIdToken(tokens.id_token,this.keys,{clientId:this.clientId,nonce:r.nonce});
  return this.session(identity);
 }
 session({sub,email}){return this.store.transaction(()=>{
  let row=this.store.db.prepare('SELECT u.id,u.email,u.role FROM google_identities g JOIN users u ON u.id=g.user_id WHERE sub=?').get(sub);
  if(!row){if(this.store.db.prepare('SELECT id FROM users WHERE email=?').get(email))throw new HttpError(409,'Для этого email уже есть аккаунт. Войдите по паролю; автоматическое объединение аккаунтов отключено.');
   row=this.store.register({email,password:random(),role:'buyer'});this.store.db.prepare('INSERT INTO google_identities VALUES(?,?)').run(sub,row.id);
  }
  const token=random();this.store.db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(token),row.id,Date.now()+86400000);return {token,user:row};
 });}
}
