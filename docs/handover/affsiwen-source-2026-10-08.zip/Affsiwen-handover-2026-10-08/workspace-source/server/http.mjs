import {Onboarding,DemoIntake,LlmIntake} from './onboarding.mjs';
import {GoogleAuth} from './google-auth.mjs';
import {publicOrigin} from './runtime-config.mjs';
import {createServer} from 'node:http';
import {randomBytes} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {mkdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {resolve,extname} from 'node:path';
import {Worker,HttpError} from './store.mjs';
import {MarketStore as Store} from './market-store.mjs';
import {marketApi} from './market-api.mjs';
import {FixtureProvider,StripeTestProvider,ApifyProvider} from './providers.mjs';
const root=fileURLToPath(new URL('../dist/',import.meta.url));
const cookie=req=>{const value=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('affsiwen_session='));return value?.slice('affsiwen_session='.length)||'';};
async function body(req){let n=0;const chunks=[];for await(const chunk of req){n+=chunk.length;if(n>65536)throw new HttpError(413,'Слишком большой запрос.');chunks.push(chunk);}return Buffer.concat(chunks);}
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.ttf':'font/ttf'};
export function createApp({store=new Store(),origin='http://127.0.0.1:4180',stripe=null,demoAccess=false,execution='fixture',intakeProvider=new DemoIntake(),intakeDailyLimit=100,googleConfig={}}={}){
 if(demoAccess&&(!['127.0.0.1','localhost'].includes(new URL(origin).hostname)||stripe||execution!=='fixture'))throw Error('Demo role access is restricted to local fixture-only environments');
 const failures=new Map(),demoUsers=new Map(),intake=new Onboarding(store,intakeProvider,intakeDailyLimit),google=new GoogleAuth(store,{...googleConfig,origin});
 const readCookie=(req,name)=>(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1)||'';
 const setCookie=(name,value,age=86400,sameSite='Strict')=>`${name}=${value}; HttpOnly; SameSite=${sameSite}; Path=/; Max-Age=${age}${origin.startsWith('https:')?'; Secure':''}`;
 const rate=(key,max=20)=>{const now=Date.now();for(const [k,e] of failures)if(e.until<now)failures.delete(k);const e=failures.get(key)||{count:0,until:now+60000};failures.set(key,e);if(++e.count>max)throw new HttpError(429,'Слишком много запросов. Подождите минуту.');};
 const server=createServer(async(req,res)=>{
  const json=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  try{
   if(req.headers.host!==new URL(origin).host)throw new HttpError(403,'Host not allowed');
   const url=new URL(req.url,origin),path=url.pathname;
   if(!path.startsWith('/api/')){
    if(req.method!=='GET'&&req.method!=='HEAD')throw new HttpError(405,'Method not allowed');
    if(['/index.html','/pilot.html'].includes(path)){res.writeHead(302,{Location:'/market.html'});return res.end();}
    if(!['/','/market.html','/amazon.js','/market.js','/economics-ui.js','/market.css','/landing.js','/landing.css','/partner-onboarding.js','/assets/affsiwen-logo.svg','/assets/switzer-variable.ttf'].includes(path))throw new HttpError(404,'Файл не найден.');
    const target=resolve(root,'.'+decodeURIComponent(path==='/'?'/market.html':path));
    if(!target.startsWith(root)||!mime[extname(target)])throw new HttpError(404,'Файл не найден.');
    const contents=await readFile(target).catch(()=>{throw new HttpError(404,'Файл не найден.');});
    res.writeHead(200,{'Content-Type':mime[extname(target)],'Cache-Control':'no-cache'});return res.end(req.method==='HEAD'?undefined:contents);
   }
   if(req.method==='GET'&&path==='/api/health')return json(200,{mode:'server-workspace',database:true,execution:execution==='fixture'?'fixture':'managed',assistant:intakeProvider.mode,googleLogin:google.enabled,payments:stripe?'stripe_test':'fixture',commercialSales:false,demoAccess});
   if(req.method==='GET'&&path==='/api/auth/google/start'){rate('oauth:'+req.socket.remoteAddress,10);const start=google.start();res.setHeader('Set-Cookie',setCookie('affsiwen_oauth',start.binding,600,'Lax'));res.writeHead(302,{Location:start.url,'Cache-Control':'no-store'});return res.end();}
   if(req.method==='GET'&&path==='/api/auth/google/callback'){
    try{const session=await google.finish(url.searchParams.get('state'),readCookie(req,'affsiwen_oauth'),url.searchParams.get('code'));res.setHeader('Set-Cookie',[setCookie('affsiwen_session',session.token),setCookie('affsiwen_oauth','',0,'Lax')]);res.writeHead(303,{Location:'/market.html#resume','Cache-Control':'no-store'});return res.end();}
    catch{res.setHeader('Set-Cookie',setCookie('affsiwen_oauth','',0,'Lax'));res.writeHead(303,{Location:'/market.html#login/google-error','Cache-Control':'no-store'});return res.end();}
   }
   if(req.method==='GET'&&path==='/api/onboarding')return json(200,{...intake.read(readCookie(req,'affsiwen_intake')),mode:intakeProvider.mode});
   const raw=req.method==='POST'?await body(req):Buffer.alloc(0);
   if(path==='/api/stripe/webhook'&&req.method==='POST'){
    if(!stripe)throw new HttpError(503,'Stripe test mode не подключён.');
    let event;try{event=stripe.event(raw,req.headers['stripe-signature']);}catch{throw new HttpError(400,'Неверная подпись события.');}
    store.recordStripe(event);return json(200,{received:true});
   }
   if(req.method==='POST'&&(req.headers.origin!==origin||req.headers['x-affsiwen-request']!=='1'))throw new HttpError(403,'Origin check failed');
   let data={};if(raw.length){try{data=JSON.parse(raw);}catch{throw new HttpError(400,'Некорректный JSON.');}}
   if(req.method==='POST'&&path==='/api/onboarding'){rate('intake:'+req.socket.remoteAddress,12);let answer;try{answer=await intake.send(readCookie(req,'affsiwen_intake'),data);}catch(e){if(e.status)throw e;throw new HttpError(503,'Ассистент временно недоступен. Попробуйте ещё раз или откройте каталог.');}const {token,...out}=answer;res.setHeader('Set-Cookie',setCookie('affsiwen_intake',token));return json(200,out);}
   if(req.method==='POST'&&path==='/api/onboarding/reset'){res.setHeader('Set-Cookie',setCookie('affsiwen_intake','',0));return json(200,{ok:true});}
   if(req.method==='POST'&&path==='/api/demo-session'){
    if(!demoAccess||!['buyer','supplier','operator'].includes(data.role))throw new HttpError(403,'Демонстрационные входы выключены.');
    if(!demoUsers.has(data.role)){const credentials={email:`local-${data.role}-${randomBytes(5).toString('hex')}@example.test`,password:randomBytes(24).toString('hex'),role:data.role};store.register(credentials,true);demoUsers.set(data.role,credentials);}
    const session=store.login(demoUsers.get(data.role));res.setHeader('Set-Cookie',`affsiwen_session=${session.token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400`);return json(200,{user:session.user});
   }
   if(req.method==='POST'&&['/api/register','/api/login'].includes(path)){
    const ip=req.socket.remoteAddress,now=Date.now(),entry=failures.get(ip)||{count:0,until:now+60000};if(entry.until<now){entry.count=0;entry.until=now+60000;}failures.set(ip,entry);
    if(++entry.count>20)throw new HttpError(429,'Слишком много попыток. Подождите минуту.');
    if(path==='/api/register')return json(201,{user:store.register(data)});
    const session=store.login(data);res.setHeader('Set-Cookie',`affsiwen_session=${session.token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${origin.startsWith('https:')?'; Secure':''}`);return json(200,{user:session.user});
   }
   const user=store.user(cookie(req));
   if(marketApi({store,user,path,method:req.method,data,json,res}))return;
   if(!user)throw new HttpError(401,'Войдите в аккаунт.');
   if(req.method==='GET'&&path==='/api/me')return json(200,{user});
   if(req.method==='POST'&&path==='/api/logout'){store.logout(cookie(req));res.setHeader('Set-Cookie',[setCookie('affsiwen_session','',0),setCookie('affsiwen_intake','',0)]);return json(200,{ok:true});}
   if(req.method==='GET'&&path==='/api/orders')return json(200,{orders:store.visible(user)});
   if(req.method==='POST'&&path==='/api/orders'){const o=store.create(user,data,stripe?'stripe_test':'fixture');return json(201,{order:store.publicOrder(user,o)});}
   const route=path.match(/^\/api\/orders\/([\w-]+)(?:\/(checkout|pay-test|accept|refund-test|export))?$/);
   if(route){const [,id,action]=route;store.read(user,id);
    if(req.method==='GET'&&!action)return json(200,{order:store.read(user,id)});
    if(req.method==='GET'&&action==='export'){const o=store.read(user,id);if(!['delivered','accepted'].includes(o.status))throw new HttpError(409,'Результат недоступен.');res.setHeader('Content-Disposition',`attachment; filename="affsiwen-${id}.json"`);return json(200,o.result);}
    if(req.method==='POST'&&action==='checkout'){
     const o=store.get(id);if(o.buyerId!==user.id||o.status!=='awaiting_payment')throw new HttpError(409,'Оплата недоступна.');
     if(!stripe)throw new HttpError(503,'Stripe ещё не подключён.');
     const session=await stripe.checkout(o);store.transaction(()=>{const current=store.get(id);if(current.paymentSessionId&&current.paymentSessionId!==session.id)throw new HttpError(409,'Checkout session mismatch');current.paymentSessionId=session.id;store.save(current,'checkout.created');});return json(200,{url:session.url});
    }
    if(req.method==='POST'&&action==='pay-test')return json(200,{order:store.publicOrder(user,store.payFixture(user,id))});
    if(req.method==='POST'&&action==='accept')return json(200,{order:store.publicOrder(user,store.accept(user,id))});
    if(req.method==='POST'&&action==='refund-test')return json(200,{order:store.publicOrder(user,store.refundFixture(user,id))});
   }
   throw new HttpError(404,'Маршрут не найден.');
  }catch(e){json(e.status||500,{error:e.status?e.message:'Ошибка сервера. Повторите запрос с тем же ключом.'});}
 });
 return {server,store};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){
 if(process.env.NODE_ENV==='production')throw Error('Local pilot only. Production auth, database and launch gates must be configured first.');
 const dir=resolve(process.env.DATA_DIR||'var');mkdirSync(dir,{recursive:true,mode:0o700});
 const store=new Store(resolve(dir,'pilot.sqlite'));store.recover();
 const port=Number(process.env.PORT||4180),origin=publicOrigin(process.env,port);
 const stripe=process.env.STRIPE_SECRET_KEY?new StripeTestProvider({key:process.env.STRIPE_SECRET_KEY,webhookSecret:process.env.STRIPE_WEBHOOK_SECRET,origin}):null;
 const provider=process.env.APIFY_EXECUTION_APPROVED==='yes'?new ApifyProvider({token:process.env.APIFY_TOKEN,spendApproved:true,maxChargeUsd:Number(process.env.APIFY_MAX_RUN_USD||2),build:process.env.APIFY_BUILD}):new FixtureProvider();
 if(provider.mode==='apify'&&!stripe)throw Error('Apify execution requires Stripe sandbox; fixture payment cannot trigger spending');
 const demoAccess=process.env.LOCAL_DEMO_ACCESS==='yes';
 const intakeProvider=process.env.AFFSIWEN_LLM_ENABLED==='yes'?new LlmIntake({key:process.env.AFFSIWEN_LLM_API_KEY,model:process.env.AFFSIWEN_LLM_MODEL}):new DemoIntake();
 const intakeDailyLimit=Number(process.env.AFFSIWEN_LLM_DAILY_CALLS||100);if(!Number.isInteger(intakeDailyLimit)||intakeDailyLimit<1||intakeDailyLimit>1000)throw Error('Invalid LLM daily call limit');
 const {server}=createApp({store,origin,stripe,demoAccess,execution:provider.mode,intakeProvider,intakeDailyLimit,googleConfig:{clientId:process.env.GOOGLE_CLIENT_ID,clientSecret:process.env.GOOGLE_CLIENT_SECRET}}),worker=new Worker(store,provider);
 const timer=setInterval(()=>worker.tick().catch(()=>console.error('Worker tick failed')),1500);
 server.listen(port,process.env.HOST||'127.0.0.1',()=>console.log(`Affsiwen local pilot: ${origin}/market.html (server workspace; synthetic execution, no live sales)`));
 process.on('SIGTERM',()=>{clearInterval(timer);server.close(()=>{store.close();process.exit(0);});});
}
