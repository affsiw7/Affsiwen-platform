import {quoteProspecting} from './economics.mjs';
import {HttpError} from './store.mjs';
import {csv} from './catalog.mjs';
export function marketApi({store,user,path,method,data,json,res}){
 if(!store.catalog)return false;
 if(method==='GET'&&path==='/api/catalog'){json(200,{products:store.catalog(user)});return true;}
 if(!user)return false;
 if(method==='POST'&&path==='/api/economics/quote'){if(user.role!=='operator')throw new HttpError(403,'Нужен оператор.');json(200,quoteProspecting(data));return true;}
 if(method==='GET'&&path==='/api/favorites'){json(200,{ids:store.favorites(user)});return true;}
 if(method==='POST'&&path==='/api/catalog'){json(201,{product:store.propose(user,data)});return true;}
 if(method==='GET'&&path==='/api/operations'){json(200,store.overview(user));return true;}
 if(method==='GET'&&path==='/api/launch'){if(user.role!=='operator')throw new HttpError(403,'Нужен оператор.');json(200,{commercialSales:false,items:[{name:'Каталог и заказы',status:'ready',note:'Серверная база, роли, сохранённые цены и результаты'},{name:'Исполнение Agent',status:'pending',note:'Нужны серверный токен, проверенный контракт каждого Agent и согласованный бюджет'},{name:'Stripe',status:'pending',note:'Sandbox аккаунт подтверждён; ключ приложения и webhook ещё не подключены'},{name:'Resend',status:'pending',note:'Отдельное пространство Affsiwen ожидает решения по платному тарифу'},{name:'Размещение и домен',status:'pending',note:'Сервер ещё не развёрнут; требуется отдельный ресурс Affsiwen'},{name:'Коммерческие условия',status:'pending',note:'Права, измеренная себестоимость, цены, налоги и возвраты'}]});return true;}
 const product=path.match(/^\/api\/catalog\/([\w-]+)(?:\/(favorite|qualify))?$/);
 if(product&&method==='POST'){json(200,product[2]==='qualify'?{product:store.qualify(user,product[1],data)}:product[2]?{ids:store.favorite(user,product[1])}:{product:store.revise(user,product[1],data)});return true;}
 const order=path.match(/^\/api\/orders\/([\w-]+)\/(events|messages|cancel|dispute|reread|cost|csv)$/);
 if(!order)return false;const [,id,action]=order;store.read(user,id);
 if(method==='GET'&&action==='events'){json(200,{events:store.events(user,id)});return true;}
 if(action==='messages'&&['GET','POST'].includes(method)){json(200,{messages:method==='GET'?store.messages(user,id):store.message(user,id,data.body)});return true;}
 if(method==='GET'&&action==='csv'){const o=store.read(user,id);if(!['delivered','accepted'].includes(o.status))throw new HttpError(409,'Выдача ещё не готова.');res.writeHead(200,{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="affsiwen-${id}.csv"`,'Cache-Control':'no-store'});res.end(csv(o.result));return true;}
 if(method==='POST'&&['cancel','dispute','reread','cost'].includes(action)){const o=action==='cancel'?store.cancel(user,id):action==='dispute'?store.dispute(user,id,data.reason):action==='reread'?store.resume(user,id):store.reconcileCost(user,id,data);json(200,{order:store.publicOrder(user,o)});return true;}
 return false;
}
