import {fixtureRows,readiness} from './catalog.mjs';
import {createHmac,timingSafeEqual} from 'node:crypto';
import {ADS_ACTOR,buildActorInput,demoRawAds} from '../dist/ads.js';
const check=(ok,message)=>{if(!ok)throw Error(message);};
const providerId=id=>{check(/^[a-zA-Z0-9_-]{1,100}$/.test(id||''),'Invalid provider ID');return id;};
async function jsonRequest(fetcher,url,options={}) {
 const res=await fetcher(url,{...options,redirect:'error',signal:AbortSignal.timeout(20000)});
 // Do not propagate remote bodies: errors may contain secrets or customer inputs.
 if(!res.ok)throw Error(`Provider HTTP ${res.status}`);
 return res.json();
}
export class FixtureProvider {
 mode='fixture';
 async start(order){return {id:`fixture_${order.id}`,status:'RUNNING'};}
 async poll(order){return {status:'SUCCEEDED',defaultDatasetId:order.id,usageTotalUsd:null};}
 async results(order){return order.product?fixtureRows(order):demoRawAds(order.input);}
}
export class ApifyProvider {
 mode='apify';
 constructor({token,spendApproved=false,maxChargeUsd=2,build,fetcher=fetch}){
  check(token&&spendApproved,'Apify requires a server token and explicit spending approval');
  check(Number.isFinite(maxChargeUsd)&&maxChargeUsd>0&&maxChargeUsd<=10,'Invalid Apify run budget');
  check(typeof build==='string'&&/^[\w.-]{1,80}$/.test(build)&&build!=='latest','Pin a tested Actor build before live execution');
  Object.assign(this,{token,maxChargeUsd,build,fetcher});
 }
 async request(path,options={}){return jsonRequest(this.fetcher,'https://api.apify.com/v2/'+path,{...options,headers:{Authorization:`Bearer ${this.token}`,'Content-Type':'application/json'}});}
 async start(order){
  const product=order.product;
  if(product)check(readiness(product).ready,'Product has not passed commercial validation');
  const contract=product?.execution;
  const actor=product?.actor||ADS_ACTOR;
  check(/^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_-]+$/.test(actor),'Invalid Actor');
  const actorInput=contract?{...contract.template}:buildActorInput(order.input);
  if(contract){check(contract.mapping&&typeof contract.mapping==='object','Verified input mapping required');for(const [target,source] of Object.entries(contract.mapping)){check(!['__proto__','constructor','prototype'].includes(target)&&['query','limit','country'].includes(source),'Invalid input mapping');actorInput[target]=order.input[source];}}
  const q=new URLSearchParams({timeout:'300',memory:'1024',maxTotalChargeUsd:String(this.maxChargeUsd),build:contract?.build||this.build});
  // POST is deliberately not retried: a timeout can hide a successfully created, billable run.
  const {data}=await this.request(`acts/${actor.replace('/','~')}/runs?${q}`,{method:'POST',body:JSON.stringify(actorInput)});
  check(data?.id,'Apify response missing run ID');return {id:providerId(data.id),status:data.status};
 }
 async poll(order){const {data}=await this.request(`actor-runs/${providerId(order.runId)}`);check(data&&typeof data.status==='string','Invalid Apify run');return data;}
 async results(order,run){
  check(run.status==='SUCCEEDED','Run is not finished');
  const limit=order.product?order.input.limit:300;
  const rows=await this.request(`datasets/${providerId(run.defaultDatasetId)}/items?format=json&clean=true&limit=${limit+1}`);
  check(Array.isArray(rows)&&rows.length<=limit,'Unexpected dataset size; operator review required');return rows;
 }
}
export function verifyStripeEvent(raw,signature,secret,now=Date.now()){
 check(typeof secret==='string'&&secret.startsWith('whsec_'),'Stripe signing secret missing');
 check(typeof signature==='string','Missing Stripe signature');
 const parts=signature.split(',').map(s=>s.split('='));
 const t=parts.find(([k])=>k==='t')?.[1];
 check(/^\d+$/.test(t||'')&&Math.abs(now/1000-Number(t))<=300,'Expired Stripe signature');
 const expected=createHmac('sha256',secret).update(`${t}.`).update(raw).digest();
 check(parts.some(([k,v])=>k==='v1'&&/^[0-9a-f]{64}$/i.test(v||'')&&timingSafeEqual(expected,Buffer.from(v,'hex'))),'Invalid Stripe signature');
 const event=JSON.parse(raw.toString());check(event.id&&event.data?.object,'Invalid Stripe event');
 return event;
}
export class StripeTestProvider {
 constructor({key,webhookSecret,origin,fetcher=fetch}){
  check(key?.startsWith('sk_test_'),'Only Stripe test keys are permitted in this pilot');
  check(/^https:\/\//.test(origin)||/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin),'Invalid application origin');
  Object.assign(this,{key,webhookSecret,origin,fetcher});
 }
 async checkout(order){
  const body=new URLSearchParams({mode:'payment','payment_method_types[0]':'card',success_url:`${this.origin}/market.html#order/${order.id}`,cancel_url:`${this.origin}/market.html#order/${order.id}`,'line_items[0][quantity]':'1','line_items[0][price_data][currency]':'eur','line_items[0][price_data][unit_amount]':String(order.amountCents),'line_items[0][price_data][product_data][name]':`Affsiwen — ${order.product?.title||'Meta creative collection'} (test)`,'metadata[order_id]':order.id,client_reference_id:order.id});
  const session=await jsonRequest(this.fetcher,'https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{Authorization:`Bearer ${this.key}`,'Content-Type':'application/x-www-form-urlencoded','Idempotency-Key':`checkout-${order.id}`},body});
  check(session.id&&session.url&&new URL(session.url).origin==='https://checkout.stripe.com','Invalid Stripe checkout response');return {id:session.id,url:session.url};
 }
 event(raw,signature){const event=verifyStripeEvent(raw,signature,this.webhookSecret);check(event.livemode===false,'Live Stripe events are disabled');return event;}
}
