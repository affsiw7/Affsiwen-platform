import test from 'node:test';
import assert from 'node:assert/strict';
import {seed,actor,purchase,advance,supplierAvailable,payout,topup,saveProduct,productAction,addMessage,ticket,replyTicket} from '../dist/domain.js';
const buyer=actor('buyer'),supplier=actor('supplier'),operator=actor('operator');
const input={productId:'p1',query:'Synthetic test app',country:'DE',format:'CSV',quantity:1};
test('purchase → supplier delivery → acceptance → payout conserves money',()=>{
 const s=seed(),before=s.balance,o=purchase(s,buyer,input);
 assert.equal(s.balance,before-o.total);assert.equal(o.status,'queued');
 advance(s,supplier,o.id,'start');advance(s,supplier,o.id,'deliver');
 assert.equal(supplierAvailable(s),0);assert.equal(o.result.length,8);assert.ok(o.result.every(r=>r.synthetic));
 advance(s,buyer,o.id,'accept');assert.equal(supplierAvailable(s),o.wholesale);
 assert.throws(()=>advance(s,buyer,o.id,'accept'));assert.equal(supplierAvailable(s),o.wholesale);
 const paid=payout(s,supplier);assert.equal(paid.amount,o.wholesale);assert.equal(supplierAvailable(s),0);assert.throws(()=>payout(s,supplier));
 assert.equal(o.total,paid.amount+(o.total-o.wholesale));
});
test('cancellation refunds once, insufficient balance never creates order',()=>{
 const s=seed(),before=s.balance,o=purchase(s,buyer,input);advance(s,buyer,o.id,'cancel');assert.equal(s.balance,before);assert.throws(()=>advance(s,buyer,o.id,'cancel'));assert.equal(s.balance,before);
 s.balance=0;const n=s.orders.length;assert.throws(()=>purchase(s,buyer,input));assert.equal(s.orders.length,n);
});
test('dispute freezes earning and operator refund credits buyer exactly once',()=>{
 const s=seed(),o=s.orders[0],before=s.balance;advance(s,buyer,o.id,'dispute','Result does not match requested format');assert.equal(supplierAvailable(s),0);assert.throws(()=>advance(s,buyer,o.id,'accept'));assert.throws(()=>advance(s,operator,o.id,'refund','short'));
 advance(s,operator,o.id,'refund','Quality issue confirmed by operator');assert.equal(s.balance,before+o.total);assert.equal(supplierAvailable(s),0);assert.throws(()=>advance(s,operator,o.id,'refund','Repeated decision'));assert.equal(s.balance,before+o.total);
});
test('failure during execution returns funds and blocks delivery',()=>{
 const s=seed(),before=s.balance,o=purchase(s,buyer,input);advance(s,supplier,o.id,'start');assert.throws(()=>advance(s,buyer,o.id,'cancel'));advance(s,supplier,o.id,'fail');assert.equal(s.balance,before);assert.throws(()=>advance(s,supplier,o.id,'deliver'));
});
test('invalid actor, role or foreign order cannot mutate workflow',()=>{
 const s=seed(),o=purchase(s,buyer,input);assert.throws(()=>advance(s,buyer,o.id,'start'));assert.throws(()=>advance(s,{role:'supplier',accountId:'other'},o.id,'start'));
 o.supplierId='supplier-2';assert.throws(()=>advance(s,supplier,o.id,'start'));assert.throws(()=>addMessage(s,supplier,o.id,'hello'));assert.equal(o.status,'queued');assert.throws(()=>topup(s,supplier,100));assert.throws(()=>purchase(s,operator,input));
});
test('price is snapshotted and changing catalogue cannot change order',()=>{
 const s=seed(),o=purchase(s,buyer,input),total=o.total,cost=o.wholesale;s.products[0].retail=99900;s.products[0].wholesale=88800;assert.equal(o.total,total);assert.equal(o.wholesale,cost);
});
test('onboarding requires mock endpoint and rights, moderation gates sale',()=>{
 const s=seed(),p=saveProduct(s,supplier,{title:'Test solution',description:'A synthetic solution for testing the whole flow',retail:2900,wholesale:1100,unit:'100 demo rows',type:'web',category:'Данные для AI',source:'Synthetic data',endpoint:'https://example.com/run',rights:true});
 assert.throws(()=>purchase(s,buyer,{...input,productId:p.id}));assert.throws(()=>productAction(s,supplier,p.id,'submit'));productAction(s,supplier,p.id,'verify');productAction(s,supplier,p.id,'submit');assert.throws(()=>productAction(s,supplier,p.id,'approve'));
 productAction(s,operator,p.id,'reject','Please clarify the output schema');assert.equal(p.status,'rejected');productAction(s,supplier,p.id,'submit');productAction(s,operator,p.id,'approve');const o=purchase(s,buyer,{...input,productId:p.id});assert.equal(o.total,2900);productAction(s,supplier,p.id,'pause');assert.throws(()=>purchase(s,buyer,{...input,productId:p.id}));productAction(s,supplier,p.id,'resume');assert.equal(p.status,'active');
});
test('money and package validation rejects negative, NaN and excessive input',()=>{
 const s=seed();for(const amount of [-10,0,NaN,1.2,1000001])assert.throws(()=>topup(s,buyer,amount));for(const quantity of [0,-1,1.1,11,NaN])assert.throws(()=>purchase(s,buyer,{...input,quantity}));assert.throws(()=>purchase(s,buyer,{...input,format:'EXE'}));assert.throws(()=>purchase(s,buyer,{...input,country:'invalid'}));
});
test('messages and support flow persist across role views',()=>{
 const s=seed(),o=s.orders[0];addMessage(s,buyer,o.id,'Please check the file');addMessage(s,supplier,o.id,'The file is ready');assert.deepEqual(o.messages.map(m=>m.role),['buyer','supplier']);const t=ticket(s,buyer,{subject:'Question about order',text:'Please explain the demo format'});assert.throws(()=>replyTicket(s,supplier,t.id,'Here is the answer'));replyTicket(s,operator,t.id,'CSV and JSON are supported');assert.equal(t.status,'resolved');assert.throws(()=>replyTicket(s,operator,t.id,'Cannot reply twice'));
});
