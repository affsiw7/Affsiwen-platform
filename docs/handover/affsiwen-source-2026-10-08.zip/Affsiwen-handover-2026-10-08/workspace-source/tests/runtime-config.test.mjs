import test from 'node:test';
import assert from 'node:assert/strict';
import {publicOrigin} from '../server/runtime-config.mjs';

test('hosted origin uses trusted deployment metadata and explicit custom origin takes precedence', () => {
  assert.equal(publicOrigin({NODE_ENV:'staging',RENDER_EXTERNAL_URL:'https://affsiwen-example.onrender.com/'}),'https://affsiwen-example.onrender.com');
  assert.equal(publicOrigin({PUBLIC_ORIGIN:'https://app.example.test',RENDER_EXTERNAL_URL:'https://other.example.test'}),'https://app.example.test');
  assert.equal(publicOrigin({},4181),'http://127.0.0.1:4181');
});

test('staging cannot silently use localhost, insecure cookies or local operator shortcuts', () => {
  assert.throws(()=>publicOrigin({NODE_ENV:'staging'}));
  assert.throws(()=>publicOrigin({PUBLIC_ORIGIN:'http://app.example.test'}));
  assert.throws(()=>publicOrigin({NODE_ENV:'staging',PUBLIC_ORIGIN:'https://app.example.test',LOCAL_DEMO_ACCESS:'yes'}));
  for(const origin of ['https://name:[contact withheld]','https://app.example.test/path','https://app.example.test/?x=1','https://app.example.test/#x','ftp://app.example.test'])assert.throws(()=>publicOrigin({PUBLIC_ORIGIN:origin}));
});
