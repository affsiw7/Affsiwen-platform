import test from 'node:test';import assert from 'node:assert/strict';
import {calculatePricing} from '../dist/pricing.js';
test('verified Starter tariff: 300 ads cost $1.50 before repeats',()=>assert.equal(calculatePricing().rawRunUsd,1.5));
test('monthly credit is not double charged',()=>{const r=calculatePricing({orders:100});assert.equal(r.billedMonthUsd,165);assert.equal(r.provider,1.65);const low=calculatePricing({orders:10});assert.equal(low.billedMonthUsd,19);assert.equal(low.provider,1.9);});
test('VAT is excluded from revenue but included in payment fees',()=>{const r=calculatePricing({vat:20});assert.equal(r.retainedRevenue,18.43);assert.ok(Math.abs(r.payment-.592)<1e-8);});
test('target price actually yields requested contribution margin',()=>{const r=calculatePricing();const target=calculatePricing({price:r.targetPrice});assert.ok(Math.abs(target.margin-30)<1e-8);});
test('refunds retain processing and delivery costs',()=>{const r=calculatePricing({refunds:50});assert.equal(r.retainedRevenue,9.5);assert.equal(r.provider,1.65);assert.ok(Math.abs(r.payment-.535)<1e-8);});
test('reject invalid or impossible inputs',()=>{for(const value of [{orders:0},{fx:0},{ads:301},{refunds:100},{cac:NaN},{plan:'toString'},{price:''}])assert.throws(()=>calculatePricing(value));assert.equal(calculatePricing({target:99,feePercent:99}).targetPrice,null);});
