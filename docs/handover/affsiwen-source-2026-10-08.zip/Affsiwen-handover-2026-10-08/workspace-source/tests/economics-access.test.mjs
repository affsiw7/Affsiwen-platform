import test from 'node:test';
import assert from 'node:assert/strict';
import {marketApi} from '../server/market-api.mjs';
const base={};
test('local buyer/supplier cannot inspect procurement economics',()=>{
 for(const role of ['buyer','supplier'])assert.throws(()=>marketApi({store:{catalog:true},user:{role},path:'/api/economics/quote',method:'POST',data:base,json(){throw Error('leaked');}}),{status:403});
});
