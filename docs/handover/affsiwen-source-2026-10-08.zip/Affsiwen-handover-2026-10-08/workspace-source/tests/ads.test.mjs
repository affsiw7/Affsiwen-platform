import test from 'node:test';
import assert from 'node:assert/strict';
import {seed,actor,purchase,advance,tickAdJobs,controlAdJob,toggleAdFavorite,saveAdNote,supplierAvailable} from '../dist/domain.js';
import {DEMO_COMPETITORS,validateAdsInput,buildActorInput,normalizeAds,demoRawAds,compareAds,migrateAds} from '../dist/ads.js';
const buyer=actor('buyer'),supplier=actor('supplier'),operator=actor('operator');
const config=()=>validateAdsInput({competitors:DEMO_COMPETITORS,country:'DE',mediaType:'all'});
function order(s,extras={}){return purchase(s,buyer,{productId:'p2',query:'Demo competitors',country:'DE',format:'JSON',quantity:1,adsInput:config(),...extras});}
test('Actor request canonicalizes URL filters and enforces bounded collection',()=>{
 const c=config();c.competitors[0].url+='&country=US&active_status=inactive&token=secret';const r=buildActorInput(c);
 assert.equal(r.resultsLimit,100);assert.equal(r.startUrls.length,3);assert.equal(r.activeStatus,'active');assert.equal(r.isDetailsPerAd,false);assert.equal(r.enrichWithEcommerceData,false);
 const u=new URL(r.startUrls[0].url);assert.equal(u.searchParams.get('country'),'DE');assert.equal(u.searchParams.get('active_status'),'active');assert.equal(u.searchParams.has('token'),false);
});
test('Input rejects lookalike hosts, credentials, generic search and duplicates',()=>{
 for(const url of ['https://facebook.com.evil.test/ads/library/?view_all_page_id=12345','https://user:[contact withheld]/ads/library/?view_all_page_id=12345','javascript:alert(1)','https://www.facebook.com/ads/library/?q=app','https://www.facebook.com/page'])assert.throws(()=>validateAdsInput({competitors:[{url}],country:'DE',mediaType:'all'}));
 assert.throws(()=>validateAdsInput({competitors:[DEMO_COMPETITORS[0],DEMO_COMPETITORS[0]],country:'DE',mediaType:'all'}));
});
test('Normalization handles snapshot fields, duplicate IDs, unsafe links and wrong advertisers',()=>{
 const c=config(),raw=demoRawAds(c);raw.push({adArchiveID:'foreign',pageID:'77777',snapshot:{body:{text:'Wrong advertiser'}}});raw.push(null);raw[0].snapshot.linkUrl='javascript:alert(1)';
 const {ads,quality}=normalizeAds(raw,c);assert.equal(ads.length,12);assert.equal(quality.duplicates,1);assert.equal(quality.rejected,2);assert.equal(quality.complete,true);assert.equal(ads[0].landingUrl,null);assert.equal(ads[0].sourceUrl,null);assert.ok(ads.every(a=>a.synthetic));
});
test('Automatic fulfillment persists stages, clears duplicates and never repeats delivery',()=>{
 const s=seed(),before=s.balance,o=order(s);assert.equal(s.balance,before-7900);
 tickAdJobs(s,o.job.startedAt+1500);assert.equal(o.status,'processing');assert.equal(o.job.phase,'collecting');
 const restored=JSON.parse(JSON.stringify(s)),r=restored.orders.find(x=>x.id===o.id);
 tickAdJobs(restored,r.job.startedAt+6000);assert.equal(r.status,'delivered');assert.equal(r.result.length,12);assert.equal(r.job.quality.duplicates,1);assert.equal(supplierAvailable(restored),0);
 const n=r.history.length;assert.equal(tickAdJobs(restored,r.job.startedAt+9000),false);assert.equal(r.history.length,n);assert.equal(restored.balance,before-7900);advance(restored,buyer,r.id,'accept');assert.equal(supplierAvailable(restored),4200);
});
test('Failed and empty runs cannot be delivered or paid; retry is not a new purchase',()=>{
[Внутренние финансовые вводные скрыты в публичном снимке.]
 controlAdJob(s,operator,o.id,'retry');assert.equal(s.balance,balance);assert.equal(o.job.attempt,2);tickAdJobs(s,o.job.startedAt+6000);assert.equal(o.result.length,12);assert.equal(s.balance,balance);
});
test('Provider failure refunds once, respects roles and never resumes after refund',()=>{
[Внутренние финансовые вводные скрыты в публичном снимке.]
});
test('Repeat purchase creates a separate snapshot and compares stable ad IDs',()=>{
 const s=seed(),first=order(s);tickAdJobs(s,first.job.startedAt+6000);const before=s.balance,second=order(s,{previousOrderId:first.id});assert.equal(s.balance,before-7900);tickAdJobs(s,second.job.startedAt+6000);assert.equal(first.result.length,12);assert.equal(second.comparison.newIds.length,3);assert.equal(second.comparison.missingIds.length,3);assert.equal(second.previousOrderId,first.id);
 const beforeInvalid=s.balance;assert.throws(()=>order(s,{previousOrderId:first.id,adsInput:{...config(),country:'FR'}}));assert.equal(s.balance,beforeInvalid);
});
test('Favorites and notes are scoped to customer and existing result',()=>{
 const s=seed(),o=order(s);tickAdJobs(s,o.job.startedAt+6000);const id=o.result[0].id;toggleAdFavorite(s,buyer,o.id,id);assert.ok(s.favoriteAds.includes(id));saveAdNote(s,buyer,o.id,id,'Try a different CTA');assert.equal(s.adNotes[id],'Try a different CTA');assert.throws(()=>toggleAdFavorite(s,supplier,o.id,id));assert.throws(()=>saveAdNote(s,buyer,o.id,'fake','note'));toggleAdFavorite(s,buyer,o.id,id);assert.equal(s.favoriteAds.length,0);
});
test('Legacy data migration preserves old orders, money and user-edited products',()=>{
 const s=seed(),o=s.orders[0],old=JSON.stringify(o),balance=s.balance;migrateAds(s);migrateAds(s);assert.equal(JSON.stringify(o),old);assert.equal(s.balance,balance);const p=s.products.find(p=>p.id==='p2');p.title='Custom offer';delete p.adsContract;migrateAds(s);assert.equal(p.title,'Custom offer');assert.equal(p.adsContract,undefined);
});
test('Media filter and missing-page quality check do not silently fabricate coverage',()=>{
 const c={...config(),mediaType:'video'},raw=demoRawAds(c);const r=normalizeAds(raw,c);assert.equal(r.ads.length,6);assert.ok(r.ads.every(a=>a.format==='video'));assert.equal(r.quality.complete,true);const missing=normalizeAds(raw.filter(row=>row.pageID!==c.competitors[1].pageId),c);assert.equal(missing.quality.complete,false);assert.equal(missing.quality.coverage[1].count,0);assert.equal(compareAds(r.ads,null).baseline,false);
});
test('Ads checkout rejects a mismatched displayed country without charging',()=>{
 const s=seed(),balance=s.balance;assert.throws(()=>order(s,{adsInput:{...config(),country:'US'}}));assert.equal(s.balance,balance);
});
