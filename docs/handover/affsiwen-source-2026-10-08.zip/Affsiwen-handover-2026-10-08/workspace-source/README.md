# Affsiwen Platform — server marketplace v0.4

Current workspace: `http://127.0.0.1:4181/market.html` when the server is running.

```sh
LOCAL_DEMO_ACCESS=yes PORT=4181 DATA_DIR=var/market node server/http.mjs
node --test tests/*.test.mjs
```

Node 24+. Buyer, partner and operator flows now share the server database. Multi-product selection, ordering, queue, results, CSV/JSON, discussion, dispute, fixture refund and test economics are connected. External execution and payments remain disabled until dedicated credentials and launch checks are complete.

See [current implementation and launch boundaries](docs/MARKETPLACE.md). Docker staging files and backup/restore utilities are included; no cloud deployment or real purchase was performed. The sections below describe the earlier static demonstration and single-product pilot.

---

# Affsiwen — connected demo workspace

A functional, three-role demonstration of Affsiwen's direct-purchase marketplace for third-party data and automation products. Customer purchases stay inside Affsiwen. Suppliers fulfill orders under wholesale pricing; Affsiwen moderates products and handles disputes.

## Run and test

No dependencies or build step required. Node 20+ for tests; any static HTTP server for the app.

```sh
python3 -m http.server 4173 --bind 127.0.0.1 --directory dist
node --test tests/domain.test.mjs
```

Open `http://127.0.0.1:4173/#dashboard`.

## Working journeys

**Buyer:** catalog and search/category filters → product and package configuration → checkout with a demo balance → order timeline and shared messages → CSV/JSON results → acceptance or dispute. Queued orders can be cancelled with a full demo refund. Wallet, transaction export, support tickets and profile settings are functional.

**Supplier:** product creation/editing → wholesale and proposed retail pricing → mock HTTPS endpoint validation → distribution-rights declaration → submission for moderation. Published products can be paused/resumed. Customer orders progress through queued, processing and delivered. Accepted orders accrue earnings; a demo payout moves available earnings into payout history.

**Affsiwen operator:** approval or rejection of products, all orders, dispute decisions with required reasons, refund or supplier acceptance, support replies and platform economics. Approved products immediately enter the buyer's catalog. Economics separates retail receipts, supplier obligations and gross spread. The CAC calculator is a scenario, not a market forecast.

## Demo architecture and constraints

- `dist/domain.js`: deterministic business transitions, actor/ownership guards, integer-cent amounts, immutable order price snapshots, ledger entries, payout accounting and synthetic results.
- `dist/app.js`: routes, role workspaces, forms, exports and browser persistence.
- `dist/styles.css`: responsive layouts using the current Affsiwen visual identity.
- `dist/assets/`: original logo and Switzer font copied from the user-owned website.
- `tests/domain.test.mjs`: nine tests covering successful fulfillment, conservation of amounts, duplicate acceptance/refund/payout protection, failure/refund, insufficient balance, role restrictions, moderation, snapshot pricing and support.

State is versioned in browser localStorage under `affsiwen-workspace-v2`. Refresh preserves it. Other tabs on the same origin receive storage updates; different browsers and the hosted/local origins have independent demo data. There is no transactional cross-tab concurrency guarantee. Reset and JSON state export are available in settings. The old sessionStorage prototype is left untouched.

**This is a client-side demo, not a production backend.** Role switching simulates accounts and is not authentication or a security boundary. No real payment, payout, supplier API request, scraping, email or AI inference is performed. Every output is explicitly synthetic (6–8 rows, regardless of package size). All companies and catalog offers are illustrative; prices, rights and partnerships are not verified commercial offers. HTTPS endpoint validation checks only URL syntax and never contacts the endpoint. Do not enter API keys or confidential data.

## Browser verification, 29 September 2026

Verified in connected Chrome:
- €98 order → shared buyer/supplier messages → supplier processing and synthetic delivery → buyer acceptance → €48 supplier earnings → simulated payout.
- New €25 product with €10 wholesale price → draft → mock endpoint validation → review → operator approval → searchable buyer catalog.
- Dispute on the €49 seed order → operator refund → buyer balance/ledger updated and persisted after reload.
- Responsive buyer workspace at 390px viewport with no document-level horizontal overflow.
- No JavaScript console errors during the checked journeys.

## Brand provenance

User requested the existing website identity. Assets inspected and reused on 2026-09-29:
- Logo: https://affsiwen.com/assets/6925860373b222a96ab7c277_Group%2029.svg
- Font: https://affsiwen.com/assets/69245b1e0c00704d51d9a728_Switzer-Variable.ttf
- Website CSS: https://affsiwen.com/assets/css/affsiwen.webflow.shared.cef3cdb6a.css

Core tokens: Switzer with Arial fallback, cyan `#00a1de`, dark text `#202020`, white and pale gray surfaces. No third-party analytics or remote font calls.

## Before real operations

Replace the demo store with a server-side database, authenticated tenant accounts and audited role authorization; implement durable idempotent orders and accounting, supplier rights/contracts, isolated API credentials and execution, rate/cost limits, result validation, payment webhooks, tax treatment, payout eligibility, abuse prevention and data retention. The local domain tests are reusable specifications, not proof of production readiness.

The existing private GitHub repository and private Sites project are reused. `.openai/hosting.json` records the deployment project. Publishing the demo does not change the corporate website or sharing permissions.

## v2.1 — concrete creative research product

`p2` now offers **Реклама конкурентов в Meta** with a specific task and result, rather than a generic data-package form. Added automatic demo fulfillment, a provider-shaped normalization boundary for `apify/facebook-ads-scraper`, a visual gallery, advertiser/media/text filters, favorites, per-ad notes, CSV/JSON and Markdown brief export, and paid repeat collections with stable-ID comparison. Operator/supplier diagnostics support failure, empty response, retry without charging, and refund.

See [docs/CREATIVE_PRODUCT.md](docs/CREATIVE_PRODUCT.md) for the provider contract, product behavior and exact integration boundary. All Apify calls remain simulated. Updated total: 20 domain tests. Existing v2 local state is migrated without removing orders, balances or customer-edited products.

## v0.3: подготовка запуска

Расчёт по тарифам: [UNIT_ECONOMICS.md](docs/UNIT_ECONOMICS.md).
Серверный локальный пилот, запуск и точные ограничения: [SERVER_PILOT.md](docs/SERVER_PILOT.md).

`node server/http.mjs` запускает отдельный пилот на localhost:4180. Опубликованная витрина остаётся статическим демо. Apify и Stripe не подключены; реальные продажи выключены.
