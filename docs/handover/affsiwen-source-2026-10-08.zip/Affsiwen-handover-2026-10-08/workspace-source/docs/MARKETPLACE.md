# Affsiwen multi-product marketplace — 2026-09-30

## Product and operating model
Affsiwen is the seller of a packaged result. Apify is the upstream execution platform; individual Actor authors are technology suppliers. Buyers pay Affsiwen and receive results in Affsiwen. There is no invented author referral commission, author payout or wholesale agreement.

The running workspace is `/market.html`, backed by the Node API and SQLite. It replaces the separate single-product pilot as the server's default route. The old `/index.html` localStorage demonstration remains a historical UI reference; it is not the new platform database.

## Running locally
Node 24+, no npm dependencies:

```
LOCAL_DEMO_ACCESS=yes PORT=4181 DATA_DIR=var/market node server/http.mjs
```

Open `http://127.0.0.1:4181/market.html`. Login offers local buyer/operator/partner test accounts. The role endpoint is disabled by default; enabling it with a public origin, Stripe or Apify is refused. Real registration uses passwords and server sessions; buyers cannot self-register an operator. Local demo accounts are scoped to this server process; ordinary registered accounts survive restart.

## Implemented flows
- Public catalog: search, categories, sort, provenance, popularity evidence, per-user favorites.
- Buyer: product input → immutable order snapshot → fixture payment or Stripe test checkout → persistent queue → validation → results/search/CSV/JSON → accept, repeat, discuss or dispute.
- Partner: propose an Actor; inspect own proposals. Partners do not receive buyer data or invented payables.
- Operator: review all candidates, publish/pause/reject a demo offer, set scenario price, inspect all orders, answer messages, re-read an existing failed result without creating a new run, issue idempotent fixture refunds.
- Economics: separate test ledger and real revenue; order/fulfilled/repeat counts per product. Unknown costs remain unknown. Real revenue remains zero because live payments are not implemented.
- Seed selection: 12 actual Actors and public rounded Store counters observed in this session. Six start published for demonstration; six remain candidates. Sources span local businesses, social content, search, hiring, ads and public discussions. These are not a complete market scan or verified best sellers.

## Qualification and execution
Publishing is demonstration-only and does not grant commercial readiness. Authenticated operators may submit `POST /api/catalog/:id/qualify` with:
- `version`: optimistic concurrency guard;
- `rightsReference`, `testRunReference`, `costReference`: evidence references;
- `measuredCostEurCents`: full reconciled sample cost, positive and below price;
- `execution`: `{build, template, mapping, requiredOutputFields}`.

`mapping` maps validated Actor parameter names to `query`, `limit`, `country`. This first connector supports flat string/number mappings plus static template fields. Actors requiring arrays, nested inputs, login cookies, secret user credentials or specialized transformations require a reviewed adapter extension. No claim that all 12 Actors already have working live adapters is made.

Qualification is an **operator attestation**, not automatic legal verification or provider invoice verification. References are retained privately with reviewer and time. Snapshot semantics mean an existing order never silently inherits a new contract or price.

Real upstream execution requires all of: qualified product snapshot, Stripe sandbox payment, `APIFY_EXECUTION_APPROVED=yes`, server-side token, pinned build and spending caps. None have been enabled in the running fixture workspace. `APIFY_MAX_RUN_USD` defaults to 2 and `APIFY_DAILY_CAP_USD` to 10; these are disabled-mode defaults, not user-approved spending. The day budget reserves the full cap before each run and never releases it automatically after uncertain outcomes. Apify's provider-enforced cap must also be confirmed applicable to each selected pricing model before activation.

POST run creation is not retried after uncertainty. Recovery keeps it in reconciliation. Existing runs can be polled again. Partial/empty/malformed output is held for review. Required fields are configurable. Start/poll timeout, bounded result size, safe CSV cells and encoded UI values protect common failure paths.

## Infrastructure
Dockerfile and Compose prepare a **single-instance staging deployment**, not Vercel serverless. Node/SQLite requires persistent disk; do not deploy this database on an ephemeral function filesystem. Volume `affsiwen-data` is separate, container runs unprivileged, root filesystem read-only, listener published to host loopback. A separate TLS reverse proxy and PUBLIC_ORIGIN are required externally. Container build has not been verified in this environment.

`node scripts/backup.mjs` makes an online SQLite backup. `node scripts/restore.mjs source.sqlite new-target.sqlite` validates integrity and refuses to overwrite an existing database. Credentials and database are excluded from Git and container context.

## Remaining external launch work
- Dedicated approved hosting plus durable database/backups/monitoring and TLS/domain; no cloud resources created here.
- Managed or hardened production authentication: verified email, password recovery, MFA for operators, distributed rate controls and retention policies.
- Apify credentials, paid control runs, correct input/output adapters and billing reconciliation for each product. Store popularity does not disclose paid customer counts, conversion or revenue. Need longitudinal snapshots and Affsiwen paid demand tests.
- Stripe application test credentials/webhook and an actual sandbox integration test. Live payments, actual Stripe refunds, taxes/chargebacks and financial reconciliation remain unimplemented.
- Separate Affsiwen Resend workspace/domain; additional-team Pro purchase was not approved or executed. Existing Aisance resources untouched.
- Review product-specific distribution rights and applicable terms/data handling; approve unit economics and sale/refund terms.

`NODE_ENV=production` intentionally remains blocked. This build is a working local multi-product marketplace with simulated fulfillment, not a launched commercial platform.

## Verification performed
- 48 existing/new tests passed together; an additional qualification/budget test passed with the 10 marketplace tests (49 total distinct tests).
- Correct Chrome profile `Dmitriy (AFF7 Company)`: buyer fixture login, product configuration, persistent order `2eae21cf-2457-4d40-acd7-a4ea4c83926d`, demo payment, automatic 12-row delivery, acceptance.
- Operator fixture login: saw the same accepted order; published `linkedin-jobs` from candidate to demo catalog, then verified seven visible products.
- Backup and restore to a new isolated path completed. Original database untouched by restore.
- Visual desktop inspection completed. Mobile browser layout and external integrations have not been verified.
