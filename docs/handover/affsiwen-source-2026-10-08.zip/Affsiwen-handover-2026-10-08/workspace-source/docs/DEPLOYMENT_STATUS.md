# Current deployment — 2026-10-06

## 2026-10-06 — опубликовано и проверено в Chrome AFF7

Этот checkpoint заменяет прежние записи «не загружено / деплой не подтверждён».

- Полный облачный пакет опубликован в [affsiw7/Affsiwen-platform](https://github.com/affsiw7/Affsiwen-platform), ветка main: интерфейс, брендовые ресурсы, API, серверные модули, SQL, сборка, тесты, план и экономика. 32 исходных файла; внутренние базы и секреты не публиковались.
- Vercel подтвердил production **Ready** для коммита `08e7aaf64ff68d6959fd340fdb30d38e57dab4d4`, deployment `D22MJouEFULW5pSwejdwXed6RhPf`. Публичный адрес: https://affsiwen-platform.vercel.app/ . GitHub автоматически запускает публикацию.
- В браузере открывается главная с брендом Affsiwen; прежнее зависание загрузки устранено. Проверен анонимный путь: описание задачи → уточнение объёма → рекомендация Agent → карточка заказа → вход. Территория LU, запрос и объём 25 сохраняются между шагами. Платного запуска не было.
- В консоли на проверенном пути не обнаружена прежняя ошибка синтаксиса; анонимный `/api/me` возвращает ожидаемый 401. Полный аудит серверных журналов не проводился.
- Supabase показывает проект Healthy. Google-провайдер **Disabled**, email confirmation включён. Auth Site URL: `http://localhost:3000`; Redirect URLs отсутствуют. Настройки только прочитаны, без изменений.
- Google-кнопка на опубликованной форме отключена. Вход, создание заказа под реальным аккаунтом, партнёрский кабинет и операторский калькулятор в публичной сессии ещё не прошли сквозную браузерную проверку. Локальные тесты не заменяют эту проверку.
- Режим по-прежнему cloud demo: помощник детерминированный, выдача и оплата синтетические. Реальные продажи, платные API, live-платежи и рекламные расходы не включались.

### Ближайшая последовательность

1. Настроить Auth Site URL для публичного домена и точный callback `/api/auth/google/callback`; подключить отдельный Google OAuth client для Affsiwen. Проверить покупателя и партнёра, сохранение черновика и невозможность самоназначения роли оператора.
2. Пройти заказ на демоданных под каждой ролью; проверить оплату-фикстуру, статус, выдачу, экспорт, обращение и возврат.
3. Подключить отдельные письма Affsiwen и реальный LLM с контролем затрат.
4. Добавить серверный адаптер поставщика, учёт/резерв расходов, run ID, идемпотентность и сверку. После согласования конкретного лимита выполнить реальные замеры по PROSPECTING_PILOT.md.
5. Рассчитать окончательную цену по измерениям, подключить Stripe sandbox и пройти платёжные сбои/повторы/возвраты. Коммерческий запуск — только после полного проверенного пути.

---

## Historical records — superseded by checkpoint above

# Deployment checkpoint — 2026-10-01

## Дополнение 2026-10-06 — калькулятор поиска компаний

Локально добавлен операторский раздел `#economics` и защищённый API расчёта цены. Он не запускает поставщика и не меняет цену каталога. Публичный тариф Bright Data записан на сервере; будущие скидки не заложены. Пересобран allowlist-релиз из 26 файлов; тесты релиза 19/19, сборка успешна. HTTP-регрессии повторены с разрешённым локальным доступом: 35/35. Внешний деплой и визуальная проверка не выполнялись. Полный журнал: [PROJECT_LOG.md](PROJECT_LOG.md).

## Local recheck — 2026-10-06

Cloud API tests passed again (10/10). The build failed when run from the actual workspace because the syntax-check command used URL.pathname, preserving `%20` in paths with spaces. Updated it to Node's fileURLToPath; the static build now passes from the actual workspace. Regenerated the allowlisted `.release/affsiwen-platform` package. Older `/private/tmp` upload copies should not be used without refreshing them.

No external deployment, GitHub contents, account setup or live purchase flow was re-verified on this date. The external status below is the last confirmed checkpoint from October 1, not a current service audit. The published frontend correction and complete repository upload remain unconfirmed.

## Latest checkpoint: Vercel + Supabase migration

This section supersedes the historical notes below. The user selected Vercel + Supabase and explicitly authorized the public repository `affsiw7/Affsiwen-platform`.

- Supabase project `kbogufjwhjpbehtexmla`: schema, intake functions and seed applied. Live SQL acceptance checks passed for ownership, role isolation, server price snapshots, idempotency, fixture execution, refunds, supplier privacy and intake concurrency. Synthetic acceptance records were rolled back. Twelve products exist, six published; direct anonymous order access and role changes were rejected.
- Vercel project `manager-8974/affsiwen-platform` exists. Public alias: https://affsiwen-platform.vercel.app/. Production environment contains the canonical origin, Supabase URL and publishable key; no service-role key is used. Live health previously reported cloud-demo, Supabase Postgres, fixture execution/payments, disabled Google login and disabled commercial sales.
- The initially deployed browser JavaScript had a syntax error. It is fixed in the local release, and the static build now checks browser JavaScript syntax. The corrected interface has NOT yet been verified deployed; do not represent the public interface as working.
- GitHub public repository has README, cloud, api and server directories. Latest verified server commit: `3d5c32467648c7102fa0b1a778232ea5fe6acfcf`. Remaining upload: scripts, tests, dist, dist/assets, root package.json/vercel.json/.gitignore. Verify actual repository contents before resuming.
- User installed the Vercel GitHub application after the permissions page was scoped to only `affsiw7/Affsiwen-platform`. Vercel Git settings now visibly confirm `affsiw7/Affsiwen-platform`, `Connected just now`, with a Disconnect button. No other repository was connected by this task.
- Public allowlisted release: `/private/tmp/affsiwen-deploy/affsiwen-platform`. Root-file upload staging: `/private/tmp/affsiwen-root-upload`; flat interface staging: `/private/tmp/affsiwen-dist-upload`. Never upload the working repository wholesale: it contains internal documents and local database files.
- Latest local verification: cloud release tests 10/10 passed and static build passed. Earlier full suite 73/73 passed. These do not establish live account creation or end-to-end browser order acceptance.
- Google OAuth, production email, LLM, payment reconciliation and external paid execution remain unconnected/unverified. Supabase Auth site URL and redirects still need verification/configuration for the public alias. No commercial launch or paid traffic is enabled.

Current UI blocker: the native Chrome active window repeatedly switches from the permitted Dmitriy (AFF7 Company) profile to the unrelated Roman profile during file selection. A Claude browser-control banner is visible. Requested that the user pause parallel browser control before continuing; no actions on the unrelated service were taken. The Affsiwen upload file picker may remain open for the scripts directory. Reinspect before resuming. Browser-only service access remains mandatory.

## Historical checkpoint (superseded)

Status: prepared locally, not deployed externally.

The complete suite passed: 61 tests, zero failures. Provider and payment tests use substituted responses; they are not proof of live external connections. Docker is unavailable in the current local environment, so the container build remains unverified.

## Deployable target

The current application requires a single persistent Node 24 process and a writable SQLite volume. Use the existing Dockerfile and Compose staging configuration behind HTTPS. Do not deploy its database to an ephemeral Vercel function filesystem. Moving to Vercel requires a deliberate persistent database and worker migration first.

Compose now forwards dedicated Google OAuth, assistant, Stripe test and execution settings from the host. Missing optional credentials default to empty. Assistant and upstream execution default to disabled. `LOCAL_DEMO_ACCESS` is fixed to `no` externally; local QA operator logins must never be published. Do not copy `var/market` or its synthetic user accounts to a cloud deployment.

## Connection sequence

1. Verify the allowed browser profile and the dedicated Affsiwen hosting account. Confirm the available plan, persistent storage and exact project before creating a deployment.
2. Deploy a clean staging database with fixture execution, HTTPS origin and no local demo role access. Check health, registration, tenant isolation, a complete fixture order and persistence after restart.
3. Configure a dedicated Google Web OAuth client with the exact deployment callback `/api/auth/google/callback`. Complete the interactive login acceptance test. Current Google registration creates buyers; partner Google onboarding remains pending.
4. Configure the dedicated LLM credentials and an agreed model/budget, then verify that real structured recommendations use only published Affsiwen products.
5. Configure Stripe sandbox credentials and signed webhook. Complete payment, replay and wrong-amount checks against the actual sandbox. Live payments remain disabled.
6. Qualify individual upstream products, reconcile real cost and confirm the spending limit before enabling execution. Credentials alone must not bypass qualification.
7. Add the separate Affsiwen email workspace and domain after resolving its plan. Never reuse Aisance resources.

## Current access blocker

Only the Chrome profile Dmitriy (AFF7 Company), associated with [contact withheld], is authorized. The active native window belonged to the prohibited Roman profile. Automatic action review rejected opening Chrome's Window menu from that window. The user has been asked to bring the authorized Affsiwen window to the foreground. No alternate-profile actions, credential creation, uploads or external mutations were performed.

## Verified after the user switched the window

- Correct native Chrome profile: Dmitriy (AFF7 Company); new-tab Google identity shows [contact withheld].
- Vercel: manager-8974, Hobby workspace, no projects.
- Supabase: Affsiwen Platform organization `pzjydiyylgcwtybqgagm`; project `aff7 platform`, ref `kbogufjwhjpbehtexmla`, London, status Healthy. Dashboard reports no migrations, no repository and no backups. No database mutations performed.
- GitHub: `affsiw7/Affsiwen-platform` exists but is empty and **public**. Automatic review rejected changing it to private without resource-specific approval. Approval requested; no code uploaded while public.
- Apify: login email [contact withheld], GitHub identity affsiw7; personal workspace displayed as Roman / chromy_kittiwake, $0 of $5 usage, no runs. No key creation, execution or paid plan activation performed.

## Prepared hosting option, not activated

`render.yaml` declares one Node 24 staging service in Frankfurt, compute plan `0.5c-512mb`, 1 GB persistent disk at `/var/data`, tests before build, no automatic deploys or previews, fixture execution and local role shortcuts disabled. Published compute price $7/month and disk $0.25/GB/month, excluding tax and overages. User asked to choose this option within EUR 15/month or the longer migration to Vercel/Supabase. The stated budget is not a provider-enforced billing cap.

The server can use trusted `RENDER_EXTERNAL_URL` as its canonical origin; an explicit `PUBLIC_ORIGIN` overrides it. It rejects insecure external origins and local role shortcuts on staging. Fourteen relevant tests passed after this change, including two new runtime configuration tests. Earlier full suite: 61 passed; total distinct covered tests now 63. No deployment or container build was performed.

Official references inspected in the authorized browser on 2026-10-01:
- https://render.com/pricing
- https://render.com/docs/blueprint-spec

Remaining prerequisite: the chosen hosting account and approved plan, private code destination, and provider-specific credentials/consent. A registered account is not the same as a connected integration.

## Final documentation deployment verified — 2026-10-06

GitHub main `45f40babe555d0d07e80cf0401fafce1f76b29ec` contains the updated public plan and journal. The rendered journal was checked in AFF7. Vercel production `61Ei1KPnyNm8UTSCa86EF5bKfqsE` is Ready for this commit, alias https://affsiwen-platform.vercel.app/. This final local observation does not require another documentation-only deployment.

## Product storefront revision — 2026-10-06

Published concrete offers and audience/input/output/sample descriptions (`bc2e1b0`), public catalog/product navigation (`3f1f09c`, Vercel Ready verified), public plan/journal (`31c20a9`) and narrow viewport overflow correction (`6c1755d`). Build passes, cloud tests 13/13 pass. In AFF7 verified all six home offers, company detail, catalog search for реклама returning the ads product, and the ads detail with correct sample/form. No paid execution or authentication acceptance performed.
