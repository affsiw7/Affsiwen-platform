// Run locally; credentials are read from stdin, never command arguments or source.
import {Store} from '../server/store.mjs';
import {mkdirSync} from 'node:fs';
let raw='';for await(const chunk of process.stdin)raw+=chunk;
const {email,password}=JSON.parse(raw);mkdirSync('var',{recursive:true,mode:0o700});
const store=new Store('var/pilot.sqlite');const user=store.register({email,password,role:'operator'},true);store.close();console.log(JSON.stringify({id:user.id,role:user.role}));
