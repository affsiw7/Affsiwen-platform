import {publicOrigin} from '../server/runtime-config.mjs';
const origin=publicOrigin(process.env,Number(process.env.PORT||4180));
const {request}=await import('node:http');
const req=request({host:'127.0.0.1',port:process.env.PORT||4180,path:'/api/health',headers:{Host:new URL(origin).host},timeout:3000},res=>{res.resume();res.on('end',()=>process.exit(res.statusCode===200?0:1));});req.on('timeout',()=>req.destroy());req.on('error',()=>process.exit(1));req.end();
