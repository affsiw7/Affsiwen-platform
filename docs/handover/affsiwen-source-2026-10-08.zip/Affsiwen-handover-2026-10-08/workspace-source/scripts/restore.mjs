// Offline restoration only; never overwrite an existing database.
import {DatabaseSync,backup} from 'node:sqlite';import {existsSync,mkdirSync,chmodSync} from 'node:fs';import {resolve,dirname} from 'node:path';
const [source,target]=process.argv.slice(2);if(!source||!target)throw Error('Usage: node scripts/restore.mjs backup.sqlite new-location.sqlite');
if(existsSync(target))throw Error('Target exists: restoration never overwrites data.');mkdirSync(dirname(resolve(target)),{recursive:true,mode:0o700});const db=new DatabaseSync(resolve(source),{readOnly:true});if(db.prepare('PRAGMA integrity_check').get().integrity_check!=='ok')throw Error('Backup integrity check failed');await backup(db,resolve(target));db.close();chmodSync(target,0o600);console.log('Restored to '+resolve(target));
