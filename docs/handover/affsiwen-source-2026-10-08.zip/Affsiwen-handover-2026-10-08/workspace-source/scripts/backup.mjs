import {DatabaseSync,backup} from 'node:sqlite';
import {resolve} from 'node:path';import {mkdirSync,chmodSync} from 'node:fs';
const dir=resolve(process.env.DATA_DIR||'var');mkdirSync(resolve(dir,'backups'),{recursive:true,mode:0o700});
const db=new DatabaseSync(resolve(dir,'pilot.sqlite'),{readOnly:true});
const out=resolve(dir,'backups',`affsiwen-${new Date().toISOString().replaceAll(':','-')}.sqlite`);
await backup(db,out);chmodSync(out,0o600);db.close();console.log(out);
