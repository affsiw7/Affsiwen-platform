import {mkdir,readFile,writeFile,copyFile,rm,readdir} from 'node:fs/promises';
const src=new URL('../',import.meta.url),root=new URL('../.release/affsiwen-platform/',import.meta.url);
await rm(root,{recursive:true,force:true});
const files=['vercel.json','api/index.mjs','cloud/backend.mjs','cloud/schema.sql','cloud/intake.sql','cloud/seed.sql','cloud/verify.sql','server/errors.mjs','server/amazon.mjs','server/amazon-run.mjs','server/economics.mjs','server/onboarding.mjs','scripts/build-cloud.mjs','scripts/economics-report.mjs','docs/AMAZON_PRODUCT.md','docs/ECOMMERCE_PRODUCTS.md','docs/evidence/ecommerce-release-2026-10-06.json','docs/PROSPECTING_PILOT.md','docs/evidence/prospecting-scenarios.json','docs/evidence/prospecting-runs.csv','tests/cloud.test.mjs','tests/economics.test.mjs','dist/amazon.js','dist/commerce-catalog.js','server/commerce.mjs','server/travel.mjs','server/real-estate.mjs','tests/real-estate.test.mjs','docs/REAL_ESTATE_PRODUCTS.md','server/finance.mjs','server/social.mjs','server/creators.mjs','server/creators-run.mjs','tests/creators.test.mjs','docs/CREATOR_SHORTLIST.md','tests/social.test.mjs','docs/SOCIAL_POPULAR_PRODUCTS.md','docs/SOCIAL_DEMAND_RESEARCH_2026-10-06.md','tests/finance.test.mjs','docs/FINANCIAL_PRODUCTS.md','tests/travel.test.mjs','docs/TRAVEL_PRODUCTS.md','tests/commerce.test.mjs','tests/amazon.test.mjs','tests/amazon-run.test.mjs','dist/market.html','dist/market.js','dist/economics-ui.js','dist/market.css','dist/landing.js','dist/landing.css','dist/partner-onboarding.js','dist/assets/affsiwen-logo.svg','dist/assets/switzer-variable.ttf'];
for(const file of files){const target=new URL(file,root);await mkdir(new URL('.',target),{recursive:true});await copyFile(new URL(file,src),target);}
for(const name of ['PLAN.md','PROJECT_LOG.md']){await copyFile(new URL('docs/public/'+name,src),new URL('docs/'+name,root));}
const catalog=await readFile(new URL('server/catalog.mjs',src),'utf8');
const clean=catalog.slice(catalog.indexOf('export function cleanInput'),catalog.indexOf('export function fixtureRows'));
const csv=catalog.slice(catalog.indexOf('export function csv'));
await writeFile(new URL('server/catalog.mjs',root),clean+'\n'+csv);
await copyFile(new URL('cloud/README.md',src),new URL('README.md',root));
await writeFile(new URL('package.json',root),JSON.stringify({name:'affsiwen-platform',version:'0.5.0',private:true,type:'module',engines:{node:'24.x'},scripts:{build:'node scripts/build-cloud.mjs',test:'node --test tests/*.test.mjs'}},null,2)+'\n');
await writeFile(new URL('.gitignore',root),'.env\n.env.*\nnode_modules/\npublic/\n.vercel/\n*.sqlite*\n.DS_Store\n');
console.log(`Prepared ${files.length+6} allowlisted files. No account exports, secrets or local databases.`);
