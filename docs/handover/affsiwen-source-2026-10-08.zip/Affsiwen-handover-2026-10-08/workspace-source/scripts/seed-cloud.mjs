import {writeFile} from 'node:fs/promises';
import {seedProducts} from '../server/catalog.mjs';
import {customerProduct} from '../server/product-content.mjs';
const quote=v=>"'"+v.replaceAll("'","''")+"'";
const rows=seedProducts().map(p=>`(${quote(p.id)},${quote(p.status)},${quote(JSON.stringify(customerProduct(p)))}::jsonb)`);
await writeFile(new URL('../cloud/seed.sql',import.meta.url),'begin;\ninsert into affsiwen.products(id,status,document) values\n'+rows.join(',\n')+'\non conflict(id) do nothing;\ncommit;\n');
