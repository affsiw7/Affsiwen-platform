import {HttpError} from './errors.mjs';
import {financialProducts,productLinkAllowed} from '../dist/commerce-catalog.js';
const SOURCE='gd_lmrpz3vxmz972ghd7';
const check=(ok,message)=>{if(!ok)throw new HttpError(400,message);};
const columns=['Компания','Тикер','Биржа','Валюта','Цена закрытия','Предыдущее закрытие','Дата отчётности','Тип инструмента','Описание','Ссылка'];
const tasks=[{id:'search',title:'Найти компанию или инструмент',description:'Поиск по указанному клиентом тикеру или ключевому слову.',method:'discover_by_keyword'},{id:'profile',title:'Изучить компанию или инструмент',description:'Публичные биржевые сведения по ссылке Yahoo Finance.',method:'collect_by_url'}];
const cache=new Map();
const text=v=>{if(v===undefined||v===null||typeof v==='object')return '—';let s=String(v).slice(0,200).replace(/[\u0000-\u001f]/g,' ');while(Buffer.byteLength(s)>200)s=s.slice(0,-1);return s||'—';};
export function financeAdapter(id){
 const product=financialProducts.find(p=>p.id===id);if(!product)return null;
 async function inventory({key,fetcher=fetch,now=Date.now()}={}){
  if(!key)return {connected:false,reason:'not_configured',inventory:[]};const hit=cache.get(id);if(hit?.key===key&&hit.fetcher===fetcher&&hit.until>now)return hit.value;
  let value;try{const r=await fetcher('https://api.brightdata.com/datasets/v3/scrapers?domain=finance.yahoo.com',{headers:{Authorization:`Bearer ${key}`},signal:AbortSignal.timeout(15000),redirect:'error'});const b=r.ok?await r.json():null;const rows=Array.isArray(b)?b.filter(x=>x?.id===SOURCE&&x.scrapers):[];value={connected:rows.length>0,reason:rows.length?'verified':'unavailable',inventory:rows};}catch{value={connected:false,reason:'unavailable',inventory:[]};}cache.set(id,{key,fetcher,until:now+(value.connected?300000:15000),value});return value;
 }
 const available=inv=>tasks.filter(t=>inv.inventory?.some(r=>r.id===SOURCE&&r.scrapers?.[t.method]));
 function prepare(data,inv){
  check(data&&typeof data==='object','Некорректный запрос.');const task=tasks.find(t=>t.id===data.task);check(task,'Эта финансовая задача пока не подключена.');check(!data.market||data.market==='GLOBAL','Площадка и биржа определяются конкретным инструментом.');
  const value=String(data.value||'').trim(),request=String(data.request||'').trim(),limit=Number(data.limit);check(value.length>=1&&value.length<=2000&&request.length>=2&&request.length<=2000,'Укажите тикер, ключевое слово или ссылку и цель запроса.');check(Number.isInteger(limit)&&limit>=1&&limit<=100,'Объём: от 1 до 100 записей.');
  if(!inv.connected)throw new HttpError(503,'Подключение финансовых данных временно недоступно.');const row=inv.inventory.find(r=>r.id===SOURCE),contract=row?.scrapers?.[task.method];check(contract&&Array.isArray(contract.input_schema)&&contract.input_schema.length,'Эта операция сейчас недоступна.');
  let supplied;if(task.id==='profile'){check(productLinkAllowed(value,product),'Пришлите HTTPS-ссылку Yahoo Finance.');const u=new URL(value);check(/^\/quote\/[^/]+\/?$/.test(u.pathname),'Нужна ссылка на страницу инструмента Yahoo Finance.');u.hash='';supplied={url:u.href};}else{check(value.length<=200&&!/https?:|[\r\n]/i.test(value),'Для поиска укажите короткий тикер или название.');supplied={keyword:value};}
  const input={},missing=[];for(const f of contract.input_schema){if(typeof f.name!=='string')continue;const v=supplied[f.name];if(v!==undefined)input[f.name]=v;else if(f.required===true)missing.push(f.name);}check(!missing.length,'Нужно уточнить дополнительные параметры; запрос ещё не отправлен.');check(task.id==='search'?input.keyword:input.url,'Параметры операции требуют настройки.');
  const query={dataset_id:SOURCE,include_errors:'true',notify:'false'};if(task.id==='search'){query.type='discover_new';query.discover_by='keyword';}
  return {display:{product:id,task:task.id,title:task.title,market:'GLOBAL',limit,value,request,columns,mode:'prepared',priceStatus:'not_approved',notice:'Публичный снимок сведений. Цена закрытия не является котировкой в реальном времени; период и доступность полей зависят от источника.'},contract:{query,body:{input:[input],limit_per_input:limit}}};
 }
 function normalize(raw,plan){
  if(!Array.isArray(raw))throw new HttpError(502,'Источник вернул непонятный формат финансовых данных.');const good=raw.filter(r=>r&&typeof r==='object'&&!Array.isArray(r)&&!r.error&&!r.error_code);
  const rows=good.slice(0,plan.limit).map(r=>{const url=r.url;const fields={'Компания':text(r.name),'Тикер':text(r.stock_ticker),'Биржа':text(r.exchange),'Валюта':text(r.currency),'Цена закрытия':text(r.closing_price),'Предыдущее закрытие':text(r.previous_close),'Дата отчётности':text(r.earnings_date),'Тип инструмента':text(r.entity_type),'Описание':text(r.summary),'Ссылка':typeof url==='string'&&url.length<=1500&&productLinkAllowed(url,product)?url:'—'};return Object.fromEntries(plan.columns.map(k=>[k,fields[k]||'—']));}).filter(r=>Object.values(r).some(v=>v!=='—'));
  return {mode:'live',synthetic:false,product:id,rows,title:plan.title,received:raw.length,errorRecords:raw.length-good.length,requested:plan.limit,notice:'Публичные сведения из этого сбора. «—» означает отсутствующее поле. Время сбора не равно времени котировки; цена закрытия может быть устаревшей. Исторический ряд, торговое исполнение и инвестиционные рекомендации в этот результат не входят.'};
 }
 function resolveChatAnswer(answer,messages){
  if(answer?.status!=='ready'||answer.task!=='profile')return answer;
  if(productLinkAllowed(answer.value,product)&&messages.some(m=>m.role==='user'&&m.content.includes(answer.value)))return answer;
  let keyword=String(answer.value||'').trim();try{keyword=decodeURIComponent(new URL(keyword).pathname.match(/^\/quote\/([^/]+)/)?.[1]||'');}catch{}
  if(keyword&&keyword.length<=200&&messages.some(m=>m.role==='user'&&m.content.toLowerCase().includes(keyword.toLowerCase())))return {...answer,task:'search',value:keyword};
  return {...answer,status:'clarify',message:'Укажите точный тикер или название компании — подготовлю поиск по этому значению.',options:[],task:null,value:null};
 }
 return {id,product,tasks,resolveChatAnswer,markets:product.markets,inventory,available,prepare,normalize,acceptsUrl:v=>productLinkAllowed(v,product),urlPrompt:'на инструмент Yahoo Finance',chatInstructions:'Financial: GLOBAL — внутреннее значение, не гарантия всех рынков. Не спрашивай страну. Доступны только search по дословно указанному пользователем тикеру/ключевому слову и profile по его ссылке /quote/. Не угадывай тикер, биржу или валюту. Когда пользователь дал тикер или название без ссылки, всегда выбирай search; не создавай ссылку сам. Для одного инструмента предложи 1 запись; объём согласуй. Можно собрать публичные профили и поля: name, stock_ticker, exchange, currency, closing_price, previous_close, earnings_date, entity_type, summary. Цена закрытия не котировка в реальном времени. Не обещай исторические ряды, новости, прогнозы, доходность или сигналы. На запрос о том, что купить/продать, объясни доступный исследовательский результат. Нет персональных инвестиционных советов, доступа к счетам или торгового исполнения. Для анализа уже полученных строк не делай выводов о текущей стоимости без даты котировки.',publicConnection:inv=>({connected:inv.connected,reason:inv.reason,product:product.name,category:'Financial',checkedAt:new Date().toISOString(),tasks:tasks.map(({id,title,description})=>({id,title,description,available:available(inv).some(t=>t.id===id)}))})};
}
