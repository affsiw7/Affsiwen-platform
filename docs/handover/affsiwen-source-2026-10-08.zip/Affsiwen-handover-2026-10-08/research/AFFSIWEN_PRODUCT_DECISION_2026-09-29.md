> Historical research; not current product commitments. See handover/README.md.

# Affsiwen: решение по продукту — 29 сентября 2026

## Исходные ограничения

[Внутренние финансовые вводные скрыты в публичном снимке.]

## Решение

1. **Первый коммерческий тест: лицензируемый пакет локальной видимости для небольших сетей на Yext**, только вместе с поставщиком операционного исполнения. Почему: есть реальный канал реселлеров и явное направление небольших покупателей в этот канал. Это гипотеза дистрибуции, не доказанная прибыль Affsiwen.
2. **Первая проверка именно рекламного mobile: закупка пользователей для short-drama приложений через Moloco.** Почему: свежие данные о росте конкретной категории, названный покупатель, новая агентская программа. Право white label, маржа и допуск Affsiwen не подтверждены.
3. **eSIM — технически готовый запасной эксперимент, не основная инвестиция.** Простая поставка подтверждена, но сравнение с дешёвыми конкурентами резко уменьшает запас для привлечения покупателей.

## 1. Yext: Local + AI Presence для сетей 5–30 точек

Предлагаемый покупатель для проверки: сеть автосервисов или фитнес-клубов с централизованным маркетологом. Предлагаемый продукт: единое обновление адресов, часов и услуг в поддерживаемых каталогах/картах, отзывы, измерение видимости через Scout. Не включает обещание позиции в AI-ответах, производство контента или собственную разработку Affsiwen.

Фактическая коммерческая причина входа: в марте 2026 Yext описала сокращение новых прямых усилий продаж в сегменте менее $50 000 ARR и направление части SMB к реселлерам. Это не эксклюзивная территория; в сентябре компания также описала прототип Corvo AI для SMB.

На 31 января 2026 third-party reseller ARR составлял $76,369 млн, +3%. Это показатель поставщика, включающий регулярные профессиональные услуги, а не доход/прибыль реселлеров или размер всего рынка. Реальный пример канала — AdCellerant; пример конечного пользователя — Sorbet.

Что закупать: Listings, Reviews и Scout с ясными лимитами, white-label правами и операционным обслуживанием. FAQ различает обычную продуктовую поддержку и оплачиваемые услуги Operate, concierge, managed review response. Их нельзя считать включёнными по умолчанию. Цена по единице и минимальные обязательства индивидуальны; типична годовая оплата.

**Условие допуска к пилоту:** поставщик берёт на себя стандартное подключение и эксплуатацию, разрешает малый старт без крупного годового обязательства, полная закупочная цена позволяет валовую маржу минимум 40%. Это требование Affsiwen, а не опубликованное предложение Yext. Сохраняется работа по продаже, сбору исходных данных и коммерческому сопровождению.

Источники:
- https://investors.yext.com/sec-filings/all-sec-filings/content/0001628280-26-016005/ex992q4fy26shareholderlett.htm
- https://investors.yext.com/sec-filings/all-sec-filings/content/0001628280-26-027494/fy26arsform10-k.htm
- https://www.yext.com/knowledge-center/yext-faq
- https://www.yext.com/partners/reseller-partner
- https://www.yext.com/customers/adcellerant
- https://www.yext.com/customers/sorbet
- https://investors.yext.com/sec-filings/all-sec-filings/content/0001628280-26-059706/ex992q2fy27shareholderlett.htm

Тренд: Adobe измерила рост AI-переходов на US retail-сайты на 393% год к году в Q1 2026. Это изменение канала discovery; оно не доказывает результативность Yext и не измеряет европейский локальный спрос.
https://business.adobe.com/blog/ai-traffic-surge-retail-sites-not-machine-readable

## 2. Mobile: short-drama acquisition

Sensor Tower оценивает Q1 2026 в более 850 млн загрузок (+140%) и около $750 млн покупок внутри short-drama приложений (+20%). Это не рекламные расходы. Рост загрузок существенно опережает рост IAP. В числе растущих приложений названы My Drama, Shortical, Vigloo и AnyReel — примеры компаний сегмента, не подтверждённые лиды Affsiwen.

Moloco объявила глобальную агентскую программу в августе 2026. У поставщика существует managed trading: закупку ведёт собственная команда. Это не автоматически производство креативов или полное обслуживание заказчиков партнёра. Для отдельных кампаний есть минимальные бюджеты; суммы публично не раскрыты. Отдельный минимум для вступления программа не устанавливает.

Продукт для переговоров: дополнительный рекламный канал для уже работающего приложения с измерением доходов от покупок и рекламы. Клиент приносит готовое приложение, креативы и данные атрибуции. Moloco — закупка и алгоритмы; Affsiwen — продажа и коммерческое сопровождение. В кейсе ReelShort за примерно шесть недель бюджет соответствующей закупки увеличился 2,35 раза. Это результат одного клиента по внутренним данным поставщика, не обещание будущей эффективности.

**Условие допуска:** согласованные net-цены/доля, право перепродажи и использования бренда, vendor-operated исполнение, защищённый клиент, соответствие тестового минимума бюджету клиента. Медиа должно финансироваться клиентом; капитал Affsiwen не использовать для гарантии ROAS или длительного кредитования покупателей.

Источники:
- https://sensortower.com/blog/state-of-short-drama-apps-2026-report
- https://www.moloco.com/press-releases/moloco-launches-global-agency-partner-program
- https://www.moloco.com/industries/moloco-ads/agencies
- https://www.moloco.com/terms-and-policies/brand-safety-policy
- https://www.moloco.com/case-studies/reelshort

## 3. eSIM: работающая поставка, сложная дистрибуция

eSIM Access Express публикует цену $19/месяц, магазин на своём домене, собственную наценку, Stripe, автоматическую выдачу и пополнения. FAQ обещает поддержку eSIM; инструкция отдельно оставляет поддержку магазина продавцу. Нужны проверка оплаты/возвратов и небольшой рабочий баланс. Отсутствие закупки инвентаря заранее не означает отсутствие денежного обеспечения.

Каталог, проверенный браузером 29.09.2026: Japan 10GB/30d $4,70; Turkey 10GB/30d $3,21; Morocco 10GB/30d $8,71. Характеристики маршрутизации и сетей различаются. Для Японии MobiMatter продаёт IIJ 10GB/30d за $7,99: разница $3,29 до налогов, платежей, поддержки и привлечения. Большую маржу нельзя обосновывать только сравнением с более дорогим Airalo.

Juniper в октябре 2025 прогнозировала travel eSIM revenue $1,8 млрд за 2025, +85%. Это прогноз на тот момент, а не подтверждённый итог. Та же публикация предупреждает об усилении конкуренции.

Возможный тест: продажа в существующем моменте подготовки к поездке через туроператоров/тематические ресурсы. У Affsiwen этого канала пока нет; отсутствие канала — существенная причина не делать eSIM основной ставкой. Полностью готовый учёт субреселлеров Express не подтверждён.

Источники:
- https://app.esimaccess.com/faq
- https://app.esimaccess.com/public/current-price
- https://esimaccess.com/sell-esims-with-your-stripe-account/
- https://esimaccess.com/docs/terms-of-service/
- https://mobimatter.com/esim-japan
- https://www.juniperresearch.com/press/travel-esims-surge-as-roaming-alternative

## Что исключено

- Generic Epom/Bright Data: предыдущие проверки подтвердили возможность поставки, но не преимущество Affsiwen. Не выделять капитал на основании общего TAM.
- Fraud Blocker: white label ограничен просмотром отчётов; нет внешней регистрации/продвижения. https://fraudblocker.com/help/en/articles/13703594-how-to-set-up-your-custom-white-label-domain
- Otterly: нет native white label. https://help.otterly.ai/white-label
- AdCreative: white label в официальной справке ещё coming soon. https://help.adcreative.ai/en/articles/5723225-how-can-i-use-the-white-label-feature
- Своя новая AI-подписка: RevenueCat показывает увеличение числа новых подписных приложений до 14 700+ в январе 2026 и более слабое удержание AI-приложений. Это добавляет продуктовый риск к маркетинговому. https://www.revenuecat.com/state-of-subscription-apps

## Практическая последовательность

Предлагаемый лимит первой проверки — €15 000 дополнительных денежных расходов; фонд зарплаты команды в него автоматически не включён. Остальные €85 000 сохраняются до проверки продаж. Это предложение распределения капитала, не разрешение на траты.

1. Получить полноценную спецификацию Yext и Moloco по одинаковой матрице: права продажи, полная закупка, минимумы, исполнение, поддержка, возвраты, клиентская защита, выход.
2. Продолжать с одним продуктом, прошедшим фильтр. Для Yext — одна отрасль, сети 5–30 точек; для Moloco — уже работающие short-drama приложения с собственными креативами и атрибуцией.
3. Продать 3 оплачиваемых пилота. Не использовать бесплатный интерес как подтверждение спроса. Зафиксировать все часы сопровождения и фактические счета.
4. Масштабировать после первого повторного платежа, положительного вклада после прямых расходов и реалистичной окупаемости CAC. Предлагаемый порог CAC payback для подписной модели — до 6 месяцев; это управленческий критерий, не рыночный факт.

## Текст запроса поставщику — не отправлен

Affsiwen is a Luxembourg-based marketing company evaluating a distribution partnership. We want to sell a standardized, supplier-operated product, rather than build a custom implementation practice. Please quote a small pilot and subsequent volume tiers, including all platform, usage, onboarding, support and operational fees. Please specify resale and branding rights, minimum commitments, payment timing, customer protection, the work retained by Affsiwen, and exit arrangements. For Yext, include Listings, Reviews, local Scout and the operational services required to run the package. For Moloco, include managed mobile acquisition for short-drama apps, minimum campaign budgets, attribution requirements and the exact partner compensation model. We have not committed media spend or end-customer volumes.
