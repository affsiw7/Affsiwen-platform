> Historical research; not current product commitments. See handover/README.md.

# Mobile ready-product resale research — 2026-09-29

Scope: Affsiwen, marketing team, EUR100k budget, no established distribution audience or engineering team. Evidence from supplier/analyst sources plus read-only browser verification of actual public catalogs. No registration, purchase, outreach or technical product test performed.

## Best technically actionable candidate: eSIM Access Express

Product: a hosted travel-eSIM shop under Affsiwen branding. Supplier provisions and delivers connectivity; Affsiwen sets retail prices and owns checkout/marketing. An optional later B2B2C hypothesis is sales through destination-specific tour operators or travel creators before customers depart. This channel is not yet acquired or proven underserved.

Official FAQ confirms $19/month, custom domain and branding, own Stripe payments, no custom code, automated QR/one-tap delivery, topups, 11 shop languages, and supplier handling eSIM support tickets 24/7. It says there is no need to purchase inventory upfront. Source: https://app.esimaccess.com/faq

Important qualification: the 2025 setup guide requires a funded wholesale account (recommends $50 for testing), calls the product public beta, and says the reseller is first-line store support. Thus no inventory commitment does not mean zero working capital or zero support. Written confirmation is needed of the current division of payments/refunds/installation support. Source: https://esimaccess.com/sell-esims-with-your-stripe-account/

Provider identity: eSIM Access is a Redtea Mobile initiative. It operates technology and aggregates operator connectivity, not all underlying radio networks. Supplier claims 70+ MNO/MVNO integrations and its own Europe-based SM-DP+ platform. Sources: https://esimaccess.com/about-us/ and https://esimaccess.com/docs/do-i-need-to-sign-a-contract-and-a-moq-to-kickoff/

## Actual price evidence

Wholesale public catalog was verified in a live browser on 29 September 2026. It displayed 3,184 plans and update time 29 September 02:00 local / 00:00 UTC. Currency USD. Source: https://app.esimaccess.com/public/current-price

| Country/package | Public wholesale price | Route detail shown |
|---|---:|---|
| Japan 10GB, 30 days | $4.70 | Standard HK IP; IIJ JP-IP variant also $4.70 |
| Japan 20GB, 30 days | $8.20 | Standard or IIJ variant |
| Turkey 10GB, 30 days | $3.21 | NL IP; Premium variant $4.50 |
| Turkey 20GB, 30 days | $6.59 | Standard; Premium $9.25 |
| Morocco 10GB, 30 days | $8.71 | Europe IP |
| Morocco 20GB, 30 days | $15.46 | Europe IP |

Airalo public catalog was also browser-verified with currency explicitly set to USD and the Fixed Data tab selected (search-engine extraction defaults to unlimited plans):

| Country/package | Airalo public retail |
|---|---:|
| Japan 10GB / 30 days | $18.00 |
| Japan 20GB / 30 days | $25.00 |
| Turkey 10GB / 30 days | $15.50 |
| Turkey 20GB / 30 days | $22.50 |
| Morocco 10GB / 30 days | $34.00 |
| Morocco 20GB / 30 days | $43.00 |

Sources: https://www.airalo.com/japan-esim ; https://www.airalo.com/turkey-esim ; https://www.airalo.com/morocco-esim . Same volume/duration is not evidence of identical network, IP routing, speeds, support or refund terms. These are catalog prices, not completed transactions or guaranteed invoices to Affsiwen.

**Do not benchmark only against Airalo.** MobiMatter sells Japan IIJ 10GB/30 days for $7.99 and 20GB/30 days for $13.99. It sells Turkey NextLink 12GB/30 days for $8.99. These public retail offers sharply reduce the apparent pricing opportunity. Sources: https://mobimatter.com/esim-japan and https://mobimatter.com/esim-turkey . eSIM4Travel Japan10GB/30 days is $9.44: https://www.esim4travel.com/japan-esim?hsLang=en

At $7.99 retail versus $4.70 wholesale, nominal Japan gross spread is only $3.29 before VAT/sales tax treatment, processing, support, refunds and acquisition. Selling for $14.90 is a pricing hypothesis, not the cheapest offer in the market. Do not call this spread net profit or an established USP.

## Trend evidence with dates and limitations

Juniper's 7 October 2025 release forecast 2025 travel-eSIM package revenue at $1.8bn, +85% versus $989m in 2024. This is a forecast published before year end, not an audited 2025 outcome. The same release highlights increasing competition and forecasts mobile operators entering more aggressively in 2026. Source: https://www.juniperresearch.com/press/travel-esims-surge-as-roaming-alternative

GSMA's May 2026 article describes expanding adoption and forecasts 10% eSIM smartphone penetration by end2026 versus5% at end2025. Forecasts must not be presented as measured current share. Source: https://www.gsma.com/solutions-and-impact/technologies/esim/gsma_resources/esim-mass-market-deployment-moves-from-forecast-to-fact/

The demand signal is real enough for a low-cost test. It does not establish a distribution advantage for a new Affsiwen brand.

## Distribution and contract checks

Public Express documentation does not establish multi-store management, subreseller accounts, affiliate attribution or automated partner payouts. A hosted D2C store is verified; a complete Affsiwen partner-network operating system is not. A small pilot could use ordinary tracked links and manual settlement only after validating actual attribution; do not promise features not seen.

Supplier terms confirm nonexclusive resale, independent pricing, an end-user complaints channel and nonrefundable deposits. They also restrict active sales in reserved or appointed-partner territories. Get the exact permitted selling territories before choosing geography; destination coverage and sales-territory rights differ. Source: https://esimaccess.com/docs/terms-of-service/

Existing alternatives compete directly for partners: Airalo advertises standard 10% affiliate commissions, while Holafly's travel-agency offering includes supplier-operated support. This means 'we give travel agents a link and handle support' alone is not an unexplored USP. Sources: https://www.airalo.com/m/resources/airalo-affiliate-program ; https://partners.holafly.com/help-partners/

## Recommendation

Fit to resources: very high for launching a tiny test; fit to proven scalable profit: not established. Limit initial learning spend, compare actual net contribution against real retail competitors, and require a channel experiment that produces paid sales below the maximum CAC. Do not earmark EUR100k or sell it as the recommended new core business on current evidence.

The defensible direction to investigate is negotiated access to a travel distribution channel, with relevant packages embedded into its pre-departure journey, not another generic 'cheapest worldwide eSIM' brand. Existing relationships, partner willingness, conversion and repeat topups remain hypotheses.

## Other investigated mobile products

PureVPN offers turnkey branded VPN apps and reseller pricing, but its own documents assign customer relationships to the partner and only confirm supplier Tier2/3 technical support. No new demand wedge or distribution advantage for Affsiwen was found. Reject as first recommendation, not as nonexistent technology. Sources: https://www.purevpn.com/white-label/frequently-asked-questions/ ; https://www.purevpn.com/white-label/msp/

eSIM Go/Breeze can operate the storefront, integration, support and pricing for established brands, but their published best-fit customer is a brand with a large existing audience. That asset is absent at Affsiwen. Source: https://www.esimgo.com/solutions-partners/breeze
